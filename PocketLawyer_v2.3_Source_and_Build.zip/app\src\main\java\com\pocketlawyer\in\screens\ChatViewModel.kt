package com.pocketlawyer.`in`.screens

import android.app.Application
import android.content.Context
import android.content.res.Configuration
import android.util.Log
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pocketlawyer.`in`.BuildConfig
import com.pocketlawyer.`in`.R
import com.pocketlawyer.`in`.data.ChatHistory
import com.pocketlawyer.`in`.data.PocketLawyerDatabase
import com.pocketlawyer.`in`.network.ApiConfig
import com.pocketlawyer.`in`.network.ChatRequest
import com.pocketlawyer.`in`.network.GeminiContent
import com.pocketlawyer.`in`.network.GeminiPart
import com.pocketlawyer.`in`.network.RetrofitClient
import com.pocketlawyer.`in`.util.SecretUtils
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import retrofit2.HttpException
import java.util.Locale

data class ChatUiMessage(val fromUser: Boolean, val text: String)

/** Builds the instructions sent to the AI. [languageName] is the language selected in the app. */
private fun buildSystemPrompt(languageName: String): String = """
You are a friendly legal information assistant for people in India.

CRITICAL LANGUAGE MANDATE
You MUST write your entire answer 100% in $languageName script ($languageName). Even if the user types in English or another language, you MUST respond ENTIRELY in $languageName. Do NOT write in English or Latin characters except for proper noun legal section names inside brackets.

GOAL
Explain Indian laws, rights and legal procedures in very simple, clear language that an ordinary person with no legal background can understand. Answer every kind of legal question, for example: police and FIR, cyber crime, consumer complaints, workplace and salary problems, tenant and landlord issues, women's rights and safety, family matters, traffic rules and fines, property, RTI, digital privacy and courts.

HOW TO ANSWER
1. If the user only greets you or asks something very general, reply in one or two warm sentences in $languageName and invite them to describe their problem. Do not lecture.
2. For a real legal problem, answer directly and use these four short headings in $languageName: 1) Applicable Laws  2) Your Rights  3) Suggested Next Steps  4) Required Documents.
3. Use short sentences and everyday words in $languageName. If you must use a legal term, explain it in brackets.
4. Give practical steps in $languageName: who to complain to and how. Useful numbers: Police 100, Emergency 112, Women Helpline 1091, Cyber Crime Helpline 1930, Free Legal Aid (NALSA) 15100.
5. Never refuse just because the state or city is unknown. First give the general position under Indian law, then mention that details can vary by state and ask for their state only if it really matters.
6. Prefer current law. The Bharatiya Nyaya Sanhita (BNS), Bharatiya Nagarik Suraksha Sanhita (BNSS) and Bharatiya Sakshya Adhiniyam (BSA) replaced the IPC, CrPC and Evidence Act from 1 July 2024. Mention the old IPC/CrPC name too when it helps.
7. Never invent laws, section numbers, court cases or phone numbers. If you are not sure, say so honestly.
8. If the person may be in danger, first tell them to call 112 or 100 immediately.
9. Plain text only. Do not use markdown symbols such as ** or # or tables. Use numbers and line breaks.
10. End with one short line in $languageName saying this is general information and not a substitute for a qualified lawyer.
""".trimIndent()

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val db = PocketLawyerDatabase.getDatabase(application)
    private val dao = db.historyDao()

    val messages = mutableStateListOf<ChatUiMessage>()
    val isLoading = mutableStateOf(false)
    val usingOfflineFallback = mutableStateOf(!RetrofitClient.hasApiKey())

    /** Language currently selected in the app (English / Tamil / Hindi). */
    private fun currentLanguageTag(): String {
        val appLocales = AppCompatDelegate.getApplicationLocales()
        val fromApp = if (!appLocales.isEmpty()) appLocales.get(0)?.language else null
        return fromApp ?: Locale.getDefault().language
    }

    private fun currentLanguageName(): String = when (currentLanguageTag()) {
        "ta" -> "Tamil (தமிழ்)"
        "hi" -> "Hindi (हिन्दी)"
        else -> "English"
    }

    /** A context whose resources use the language chosen in the app, for localized messages. */
    private fun localizedContext(): Context {
        val app = getApplication<Application>()
        return try {
            val locale = Locale(currentLanguageTag())
            val config = Configuration(app.resources.configuration)
            config.setLocale(locale)
            app.createConfigurationContext(config)
        } catch (e: Exception) {
            app
        }
    }

    /**
     * Converts the conversation into the multi-turn format Gemini expects.
     * The newest message in [messages] is the current question, so it is excluded from the
     * history and added once at the end. Consecutive turns with the same role are merged.
     */
    private fun buildChatHistory(userPrompt: String): List<GeminiContent> {
        val turns = mutableListOf<Pair<String, String>>()

        fun addTurn(role: String, text: String) {
            val trimmed = text.trim()
            if (trimmed.isBlank()) return
            val last = turns.lastOrNull()
            if (last != null && last.first == role) {
                turns[turns.size - 1] = role to (last.second + "\n\n" + trimmed)
            } else {
                turns.add(role to trimmed)
            }
        }

        addTurn("user", buildSystemPrompt(currentLanguageName()))
        addTurn("model", "Understood. I will follow these rules.")

        val previous = messages.toList().dropLast(1).takeLast(6).dropWhile { !it.fromUser }
        for (msg in previous) {
            addTurn(if (msg.fromUser) "user" else "model", msg.text)
        }
        addTurn("user", userPrompt)

        return turns.map { (role, text) -> GeminiContent(parts = listOf(GeminiPart(text)), role = role) }
    }

    fun sendMessage(userText: String) {
        val trimmedInput = userText.trim()
        if (trimmedInput.isBlank()) return

        messages.add(ChatUiMessage(fromUser = true, text = trimmedInput))
        isLoading.value = true

        viewModelScope.launch {
            val reply = executeWithRetry(trimmedInput)
            messages.add(ChatUiMessage(fromUser = false, text = reply))
            isLoading.value = false
        }
    }

    private suspend fun executeWithRetry(userText: String): String {
        val ctx = localizedContext()
        val key = SecretUtils.getApiKey()
        if (key.isBlank() || key.contains("your_key")) {
            return offlineFallbackAnswer(ctx, userText)
        }

        val request = ChatRequest(contents = buildChatHistory(userText))
        var lastReason = "unknown"
        var emptyReply = false

        modelLoop@ for (model in ApiConfig.MODELS) {
            var currentDelay = ApiConfig.INITIAL_BACKOFF_MS

            for (attempt in 0 until ApiConfig.MAX_RETRIES) {
                try {
                    val response = RetrofitClient.api.getLegalAnswer(model, key, request)

                    val aiText = response.candidates
                        ?.firstOrNull()
                        ?.content
                        ?.parts
                        ?.mapNotNull { it.text }
                        ?.joinToString("")
                        ?.trim()

                    if (aiText.isNullOrBlank()) {
                        emptyReply = true
                        lastReason = "empty"
                        continue@modelLoop // try the next model
                    }

                    // Save to history (a database problem must never hide a good answer)
                    try {
                        dao.insertChat(
                            ChatHistory(
                                timestamp = System.currentTimeMillis(),
                                query = userText,
                                response = aiText
                            )
                        )
                    } catch (dbError: Exception) {
                        Log.e("ChatViewModel", "Could not save chat history", dbError)
                    }

                    return aiText

                } catch (e: Exception) {
                    if (e is kotlinx.coroutines.CancellationException) throw e
                    val httpCode = (e as? HttpException)?.code()
                    Log.e("ChatViewModel", "Model $model attempt ${attempt + 1} failed: HTTP $httpCode", e)
                    lastReason = if (httpCode != null) "HTTP $httpCode" else "network"

                    // No internet: retrying other models will not help
                    if (httpCode == null && attempt >= ApiConfig.MAX_RETRIES - 1) break@modelLoop

                    val temporary = httpCode == null || httpCode == 429 || httpCode >= 500
                    if (temporary && attempt < ApiConfig.MAX_RETRIES - 1) {
                        delay(currentDelay)
                        currentDelay *= 2
                        continue
                    }

                    // Invalid key / bad request: other models will fail the same way
                    if (httpCode == 401) break@modelLoop
                    // Model missing (404), forbidden (403), quota (429) or server error: try next model
                    continue@modelLoop
                }
            }
        }

        if (emptyReply && lastReason == "empty") {
            return ctx.getString(R.string.chat_empty_reply)
        }
        return ctx.getString(R.string.chat_unavailable, lastReason) + "\n\n" + offlineFallbackAnswer(ctx, userText)
    }

    fun loadChatHistory(chatId: Int) {
        if (chatId == -1) return
        viewModelScope.launch {
            isLoading.value = true
            val history = dao.getChatById(chatId)
            if (history != null) {
                messages.clear()
                messages.add(ChatUiMessage(fromUser = true, text = history.query))
                messages.add(ChatUiMessage(fromUser = false, text = history.response))
            }
            isLoading.value = false
        }
    }

    private fun offlineFallbackAnswer(ctx: Context, queryText: String = ""): String {
        val q = queryText.lowercase(Locale.ROOT)
        
        return when {
            q.contains("police") || q.contains("fir") || q.contains("arrest") || q.contains("थाना") || q.contains("போலீஸ்") -> {
                "1) Applicable Laws: Bharatiya Nagarik Suraksha Sanhita (BNSS) & Bharatiya Nyaya Sanhita (BNS).\n\n" +
                "2) Your Rights: You have the right to register a Zero FIR at any police station. Right to know grounds of arrest and consult a lawyer (Art 22).\n\n" +
                "3) Suggested Next Steps: Submit a written complaint to the Station House Officer (SHO). If refused, send it to the Superintendent of Police (SP) by registered post.\n\n" +
                "4) Required Documents: Written complaint, Identity proof, and supporting evidence.\n\nHelpline: Police 100 / Emergency 112."
            }
            q.contains("rent") || q.contains("tenant") || q.contains("landlord") || q.contains("deposit") || q.contains("किराया") || q.contains("வாடகை") -> {
                "1) Applicable Laws: Model Tenancy Act & State Rent Control Acts.\n\n" +
                "2) Your Rights: Landlords cannot forcibly evict you or cut utility supply without a valid legal notice as per the rental agreement.\n\n" +
                "3) Suggested Next Steps: Send a formal written notice to the landlord for deposit return or tenancy dispute resolution. Approach the Rent Authority if unresolved.\n\n" +
                "4) Required Documents: Rental agreement, rent payment receipts, and bank transaction statements."
            }
            q.contains("salary") || q.contains("wage") || q.contains("employer") || q.contains("job") || q.contains("वेतन") || q.contains("சம்பளம்") -> {
                "1) Applicable Laws: Payment of Wages Act & Industrial Disputes Act.\n\n" +
                "2) Your Rights: Employees are entitled to timely payment of earned wages and fair notice prior to termination.\n\n" +
                "3) Suggested Next Steps: Send a legal notice to your employer demanding unpaid salary within 15 days. Approach the Labour Commissioner's office if unpaid.\n\n" +
                "4) Required Documents: Employment contract/offer letter, pay slips, bank statements, and work emails."
            }
            q.contains("cyber") || q.contains("fraud") || q.contains("hack") || q.contains("otp") || q.contains("साइबर") || q.contains("சைபர்") -> {
                "1) Applicable Laws: Information Technology Act, 2000 & BNS.\n\n" +
                "2) Your Rights: You have the right to report online financial fraud, identity theft, or online harassment to official cyber authorities.\n\n" +
                "3) Suggested Next Steps: Report financial fraud immediately to Helpline 1930 within the golden hour, and lodge a complaint at cybercrime.gov.in.\n\n" +
                "4) Required Documents: Transaction screenshots, SMS logs, bank statement, and identity proof.\n\nHelpline: Cyber Crime 1930."
            }
            q.contains("consumer") || q.contains("defective") || q.contains("refund") || q.contains("mrp") || q.contains("उपभोक्ता") || q.contains("நுகர்வோர்") -> {
                "1) Applicable Laws: Consumer Protection Act, 2019.\n\n" +
                "2) Your Rights: Right to safety, information, repair, replacement, or full refund for defective products and deficient services.\n\n" +
                "3) Suggested Next Steps: Send a formal legal complaint notice to the seller/manufacturer. File an e-complaint on edaakhil.nic.in or National Consumer Helpline 1915.\n\n" +
                "4) Required Documents: Purchase bill/invoice, warranty card, product photos, and correspondence."
            }
            else -> ctx.getString(R.string.chat_offline_answer)
        }
    }
}
