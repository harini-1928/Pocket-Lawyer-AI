package com.pocketlawyer.`in`.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.compose.ui.res.stringResource
import com.pocketlawyer.`in`.R
import com.pocketlawyer.`in`.data.UserSession
import com.pocketlawyer.`in`.navigation.Destinations
import com.pocketlawyer.`in`.screens.common.BottomTab
import com.pocketlawyer.`in`.screens.common.PLBottomBar
import com.pocketlawyer.`in`.ui.theme.PLNavy
import com.pocketlawyer.`in`.ui.theme.PLRed
import com.pocketlawyer.`in`.ui.theme.PLTextSecondary

private data class SettingItem(val title: String, val icon: ImageVector, val route: String?, val trailingText: String? = null)

@Composable
fun ProfileScreen(navController: NavHostController, loginViewModel: LoginViewModel = viewModel()) {
    val context = LocalContext.current
    val session by loginViewModel.session.collectAsState(initial = UserSession(null, null))

    val items = listOf(
        SettingItem(stringResource(R.string.profile_edit), Icons.Filled.Person, Destinations.EDIT_PROFILE),
        SettingItem(stringResource(R.string.profile_emergency_contact), Icons.Filled.Phone, Destinations.SOS_SETUP, session.emergencyContact ?: "Not Set"),
        SettingItem(stringResource(R.string.language_title), Icons.Filled.Language, Destinations.LANGUAGE, stringResource(R.string.language_name)),
        SettingItem(stringResource(R.string.profile_privacy), Icons.Filled.Lock, Destinations.PRIVACY_POLICY),
        SettingItem(stringResource(R.string.profile_about), Icons.Filled.Info, Destinations.ABOUT)
    )

    Scaffold(bottomBar = { PLBottomBar(navController, BottomTab.PROFILE) }) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
            Text(stringResource(R.string.profile_title), style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(bottom = 16.dp))

            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 20.dp)) {
                Box(
                    modifier = Modifier.size(64.dp).background(PLNavy.copy(alpha = 0.1f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    if (session.profilePhotoUri != null) {
                        AsyncImage(
                            model = session.profilePhotoUri,
                            contentDescription = stringResource(R.string.edit_profile_photo_desc),
                            modifier = Modifier.fillMaxSize().clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Icon(Icons.Filled.Person, contentDescription = null, tint = PLNavy, modifier = Modifier.size(32.dp))
                    }
                }
                Column(modifier = Modifier.padding(start = 14.dp)) {
                    Text(if (session.hasDefaultGuestName) stringResource(R.string.guest_user) else (session.name ?: stringResource(R.string.guest_user)), style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (session.isGuest) stringResource(R.string.not_signed_in) else (session.email ?: stringResource(R.string.not_signed_in)),
                        style = MaterialTheme.typography.bodySmall,
                        color = PLTextSecondary
                    )
                }
            }

            items.forEach { item ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp)
                        .clickable(enabled = item.route != null) {
                            item.route?.let { navController.navigate(it) }
                        },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(item.icon, contentDescription = null, tint = PLNavy, modifier = Modifier.size(20.dp))
                            Text(item.title, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(start = 14.dp))
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            item.trailingText?.let {
                                Text(it, style = MaterialTheme.typography.bodyMedium, color = PLTextSecondary)
                            }
                            Icon(
                                Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                contentDescription = null,
                                tint = PLTextSecondary,
                                modifier = Modifier.padding(start = 6.dp)
                            )
                        }
                    }
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth().clickable {
                    loginViewModel.signOut(context) {
                        navController.navigate(Destinations.SPLASH) {
                            popUpTo(0)
                        }
                    }
                },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, tint = PLRed, modifier = Modifier.size(20.dp))
                    Text(stringResource(R.string.profile_logout), style = MaterialTheme.typography.bodyLarge, color = PLRed, modifier = Modifier.padding(start = 14.dp))
                }
            }
        }
    }
}
