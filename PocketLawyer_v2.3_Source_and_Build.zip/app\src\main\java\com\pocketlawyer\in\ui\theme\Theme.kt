package com.pocketlawyer.`in`.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColors = lightColorScheme(
    primary = PLNavy,
    onPrimary = PLSurface,
    primaryContainer = PLNavyLight,
    onPrimaryContainer = PLSurface,
    secondary = PLGold,
    onSecondary = PLTextPrimary,
    background = PLBackground,
    onBackground = PLTextPrimary,
    surface = PLSurface,
    onSurface = PLTextPrimary,
    surfaceVariant = PLChipBackground,
    onSurfaceVariant = PLTextPrimary,
    error = PLRed,
    onError = PLSurface
)

// The app intentionally always uses the light/navy scheme from the prototype,
// regardless of system dark mode, to keep the brand look consistent.
@Composable
fun PocketLawyerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColors,
        typography = Typography,
        content = content
    )
}
