package com.pocketlawyer.`in`.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.Context
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.pocketlawyer.`in`.R
import com.pocketlawyer.`in`.data.UserSession
import com.pocketlawyer.`in`.navigation.Destinations
import com.pocketlawyer.`in`.screens.common.PLTopBar
import com.pocketlawyer.`in`.ui.theme.PLGreen
import com.pocketlawyer.`in`.ui.theme.PLNavy
import com.pocketlawyer.`in`.ui.theme.PLRed
import com.pocketlawyer.`in`.ui.theme.PLTextSecondary
import java.util.concurrent.atomic.AtomicBoolean

@Composable
fun SosScreen(navController: NavHostController, loginViewModel: LoginViewModel = viewModel()) {
    val context = LocalContext.current
    val session by loginViewModel.session.collectAsState(initial = UserSession(null, null))
    var statusMessage by remember { mutableStateOf("") }
    var statusIsError by remember { mutableStateOf(false) }

    val onSosResult: (String, Boolean) -> Unit = { msg, isError ->
        statusMessage = msg
        statusIsError = isError
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val locGranted = results[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            results[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (locGranted) {
            // If SMS permission was refused, sendSos() falls back to the SMS composer.
            session.emergencyContact?.let { num ->
                sendSos(context, num, onSosResult)
            }
        } else {
            onSosResult(context.getString(R.string.sos_permission_error), true)
        }
    }

    fun triggerSos() {
        val contactNumber = session.emergencyContact
        if (contactNumber.isNullOrBlank()) {
            navController.navigate(Destinations.SOS_SETUP)
            return
        }

        val hasLoc = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

        if (hasLoc) {
            sendSos(context, contactNumber, onSosResult)
        } else {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    Scaffold(topBar = { PLTopBar(stringResource(R.string.sos_title), navController) }) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .padding(top = 24.dp, bottom = 12.dp)
                    .size(140.dp)
                    .background(PLRed.copy(alpha = 0.12f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Button(
                    onClick = { triggerSos() },
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = PLRed),
                    shape = CircleShape,
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                    modifier = Modifier.size(108.dp)
                ) {
                    Text("SOS", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 28.sp)
                }
            }
            Text(stringResource(R.string.sos_tap_to_alert), color = PLRed, style = MaterialTheme.typography.titleSmall)

            if (statusMessage.isNotBlank()) {
                Text(
                    statusMessage,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(top = 20.dp),
                    color = if (!statusIsError) PLGreen else MaterialTheme.colorScheme.error
                )
            }

            Card(
                modifier = Modifier.fillMaxWidth().padding(top = 32.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(stringResource(R.string.sos_configured_contact), style = MaterialTheme.typography.labelMedium, color = PLTextSecondary)
                    Text(
                        session.emergencyContact ?: stringResource(R.string.sos_none_set),
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    
                    OutlinedButton(
                        onClick = { navController.navigate(Destinations.SOS_SETUP) },
                        modifier = Modifier.padding(top = 12.dp).height(36.dp),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                    ) {
                        Text(stringResource(R.string.sos_change_number), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(stringResource(R.string.sos_what_happens), style = MaterialTheme.typography.titleSmall)
                    Box(modifier = Modifier.padding(top = 12.dp))
                    SosStep(stringResource(R.string.sos_step_location))
                    SosStep(stringResource(R.string.sos_step_nearby))
                    SosStep(stringResource(R.string.sos_step_helplines))
                }
            }

            Text(
                stringResource(R.string.sos_disclaimer),
                style = MaterialTheme.typography.bodySmall,
                color = PLTextSecondary,
                modifier = Modifier.padding(top = 24.dp)
            )

            Box(modifier = Modifier.height(24.dp))

            // HELPLINE BUTTONS
            OutlinedButton(
                onClick = { context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:100"))) },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(contentColor = PLNavy)
            ) { 
                Text(stringResource(R.string.sos_call_police), color = PLNavy, fontWeight = FontWeight.SemiBold) 
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(
                onClick = { context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:1091"))) },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(contentColor = PLNavy)
            ) { 
                Text(stringResource(R.string.sos_call_women_helpline), color = PLNavy, fontWeight = FontWeight.SemiBold) 
            }

            Spacer(modifier = Modifier.height(12.dp))

            // NEW: CALL EMERGENCY CONTACT BUTTON
            val savedNum = session.emergencyContact
            if (!savedNum.isNullOrBlank()) {
                Button(
                    onClick = { context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$savedNum"))) },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = PLNavy)
                ) {
                    Icon(Icons.Filled.Phone, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.size(8.dp))
                    Text(stringResource(R.string.sos_call_contact), color = Color.White, fontWeight = FontWeight.SemiBold)
                }
            }

            Box(modifier = Modifier.height(40.dp)) // Extra bottom padding for visibility
        }
    }
}

@Composable
private fun SosStep(text: String) {
    Row(modifier = Modifier.padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = PLGreen, modifier = Modifier.size(18.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(start = 10.dp))
    }
}

/**
 * Gets the device's current location (falling back to the last known one), then sends the SOS
 * SMS automatically. If SMS permission was refused or sending fails, opens the SMS app with the
 * message pre-filled so the user can still send it manually.
 */
private fun sendSos(
    context: Context,
    contactNumber: String,
    onResult: (String, Boolean) -> Unit
) {
    val hasFine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    val hasCoarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    if (!hasFine && !hasCoarse) {
        onResult(context.getString(R.string.sos_permission_error), true)
        return
    }

    onResult(context.getString(R.string.sos_getting_location), false)

    val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    val finished = AtomicBoolean(false)
    val handler = Handler(Looper.getMainLooper())

    fun finish(freshLocation: Location?) {
        if (!finished.compareAndSet(false, true)) return
        handler.removeCallbacksAndMessages(null)
        deliverSos(context, contactNumber, freshLocation ?: lastKnownLocation(locationManager), onResult)
    }

    val provider: String? = try {
        when {
            hasFine && locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            else -> null
        }
    } catch (e: Exception) {
        null
    }

    if (provider == null) {
        finish(null)
        return
    }

    try {
        // Give the phone up to 8 seconds to get a fresh fix, otherwise use the last known location.
        handler.postDelayed({ finish(null) }, 8000L)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            locationManager.getCurrentLocation(
                provider,
                null,
                ContextCompat.getMainExecutor(context)
            ) { location -> finish(location) }
        } else {
            val listener = object : android.location.LocationListener {
                override fun onLocationChanged(location: Location) {
                    locationManager.removeUpdates(this)
                    finish(location)
                }
                @Deprecated("Deprecated in Java")
                override fun onStatusChanged(p: String?, s: Int, e: android.os.Bundle?) {}
            }
            locationManager.requestLocationUpdates(
                provider,
                0L,
                0f,
                listener,
                Looper.getMainLooper()
            )
        }
    } catch (e: SecurityException) {
        finish(null)
    } catch (e: Exception) {
        finish(null)
    }
}

private fun lastKnownLocation(locationManager: LocationManager): Location? {
    var best: Location? = null
    for (provider in locationManager.getProviders(true)) {
        val loc = try {
            locationManager.getLastKnownLocation(provider)
        } catch (e: SecurityException) {
            null
        }
        val currentBest = best
        if (loc != null && (currentBest == null || loc.accuracy < currentBest.accuracy)) {
            best = loc
        }
    }
    return best
}

private fun deliverSos(
    context: Context,
    contactNumber: String,
    location: Location?,
    onResult: (String, Boolean) -> Unit
) {
    val locationText = if (location != null) {
        "https://maps.google.com/?q=${location.latitude},${location.longitude}"
    } else {
        context.getString(R.string.sos_location_unavailable)
    }
    val message = context.getString(R.string.sos_sms_body, locationText)

    // Open the default SMS app with the message pre-filled (Policy-compliant Intent dispatch)
    try {
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$contactNumber")).apply {
            putExtra("sms_body", message)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        onResult(context.getString(R.string.sos_sent_msg, contactNumber), false)
    } catch (e: Exception) {
        onResult(context.getString(R.string.sos_error_msg, e.message ?: "unknown"), true)
    }
}
