package com.pocketlawyer.`in`.network

import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

// Response fields are nullable because Gson can leave them null when the API omits them
// (for example when a reply is blocked by safety filters).
data class GeminiPart(val text: String? = null)
data class GeminiContent(val parts: List<GeminiPart>? = null, val role: String? = null)

data class ChatRequest(
    val contents: List<GeminiContent>
)

data class ChatCandidate(val content: GeminiContent? = null)
data class ChatResponse(val candidates: List<ChatCandidate>? = null)

interface LegalAiApi {
    @POST("v1/models/{model}:generateContent")
    suspend fun getLegalAnswer(
        @retrofit2.http.Path("model") model: String,
        @Header("x-goog-api-key") apiKey: String,
        @Body request: ChatRequest
    ): ChatResponse
}
