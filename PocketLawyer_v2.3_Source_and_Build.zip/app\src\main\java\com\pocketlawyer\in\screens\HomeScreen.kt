package com.pocketlawyer.`in`.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Sos
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.pocketlawyer.`in`.R
import com.pocketlawyer.`in`.data.SessionManager
import com.pocketlawyer.`in`.data.UserSession
import com.pocketlawyer.`in`.navigation.Destinations
import com.pocketlawyer.`in`.screens.common.BottomTab
import com.pocketlawyer.`in`.screens.common.PLBottomBar
import com.pocketlawyer.`in`.ui.theme.PLGold
import com.pocketlawyer.`in`.ui.theme.PLNavy
import com.pocketlawyer.`in`.ui.theme.PLRed
import com.pocketlawyer.`in`.ui.theme.PLTextSecondary

private data class Module(val title: String, val icon: ImageVector, val route: String, val tint: Color)

@Composable
fun HomeScreen(navController: NavHostController) {
    val context = LocalContext.current
    val sessionManager = remember { SessionManager(context) }
    val session by sessionManager.session.collectAsState(initial = UserSession(null, null))

    val modules = listOf(
        Module(stringResource(R.string.module_chat), Icons.Filled.Chat, Destinations.CHAT, PLNavy),
        Module(stringResource(R.string.module_complaint), Icons.Filled.Gavel, Destinations.COMPLAINT, PLNavy),
        Module(stringResource(R.string.module_rights), Icons.Filled.MenuBook, Destinations.RIGHTS, PLNavy),
        Module("SOS", Icons.Filled.Sos, Destinations.SOS, PLRed),
        Module(stringResource(R.string.module_quiz), Icons.Filled.Quiz, Destinations.QUIZ, PLGold),
        Module(stringResource(R.string.module_nearby), Icons.Filled.NearMe, Destinations.NEARBY, PLNavy)
    )

    Scaffold(
        bottomBar = { PLBottomBar(navController, BottomTab.HOME) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(stringResource(R.string.home_greeting, if (session.hasDefaultGuestName) stringResource(R.string.guest_first_name) else session.firstName), style = MaterialTheme.typography.titleLarge)
                    Text(
                        stringResource(R.string.home_help_prompt),
                        style = MaterialTheme.typography.bodyMedium,
                        color = PLTextSecondary
                    )
                }
                IconButton(onClick = { }) {
                    Icon(Icons.Filled.NotificationsNone, contentDescription = stringResource(R.string.notifications), tint = PLNavy)
                }
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(top = 20.dp, bottom = 16.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(modules) { module ->
                    Card(
                        modifier = Modifier.fillMaxWidth().aspectRatio(1.05f),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        onClick = { navController.navigate(module.route) }
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize().padding(14.dp),
                            verticalArrangement = Arrangement.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .background(module.tint.copy(alpha = 0.12f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(module.icon, contentDescription = module.title, tint = module.tint)
                            }
                            Text(
                                module.title,
                                style = MaterialTheme.typography.titleSmall,
                                modifier = Modifier.padding(top = 12.dp)
                            )
                        }
                    }
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = PLRed.copy(alpha = 0.08f)),
                onClick = { navController.navigate(Destinations.SOS) }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(stringResource(R.string.home_sos_card_title), style = MaterialTheme.typography.titleSmall)
                        Text(
                            stringResource(R.string.home_sos_card_sub),
                            style = MaterialTheme.typography.bodySmall,
                            color = PLTextSecondary
                        )
                    }
                    Box(
                        modifier = Modifier.size(40.dp).background(PLRed, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Filled.Sos, contentDescription = "SOS", tint = Color.White)
                    }
                }
            }
        }
    }
}
