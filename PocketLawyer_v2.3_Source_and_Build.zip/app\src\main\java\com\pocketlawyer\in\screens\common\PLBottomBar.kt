package com.pocketlawyer.`in`.screens.common

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavHostController
import com.pocketlawyer.`in`.R
import com.pocketlawyer.`in`.navigation.Destinations
import com.pocketlawyer.`in`.ui.theme.PLNavy

enum class BottomTab { HOME, HISTORY, PROFILE }

@Composable
fun PLBottomBar(navController: NavHostController, current: BottomTab) {
    NavigationBar(containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surface) {
        NavigationBarItem(
            selected = current == BottomTab.HOME,
            onClick = {
                if (current != BottomTab.HOME) {
                    navController.navigate(Destinations.HOME) {
                        popUpTo(Destinations.HOME) { inclusive = true }
                    }
                }
            },
            icon = { Icon(Icons.Filled.Home, contentDescription = stringResource(R.string.home_title)) },
            label = { Text(stringResource(R.string.home_title)) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = PLNavy,
                selectedTextColor = PLNavy,
                indicatorColor = PLNavy.copy(alpha = 0.12f)
            )
        )
        NavigationBarItem(
            selected = current == BottomTab.HISTORY,
            onClick = {
                if (current != BottomTab.HISTORY) navController.navigate(Destinations.HISTORY)
            },
            icon = { Icon(Icons.Filled.History, contentDescription = stringResource(R.string.history_title)) },
            label = { Text(stringResource(R.string.history_title)) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = PLNavy,
                selectedTextColor = PLNavy,
                indicatorColor = PLNavy.copy(alpha = 0.12f)
            )
        )
        NavigationBarItem(
            selected = current == BottomTab.PROFILE,
            onClick = {
                if (current != BottomTab.PROFILE) navController.navigate(Destinations.PROFILE)
            },
            icon = { Icon(Icons.Filled.Person, contentDescription = stringResource(R.string.profile_title)) },
            label = { Text(stringResource(R.string.profile_title)) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = PLNavy,
                selectedTextColor = PLNavy,
                indicatorColor = PLNavy.copy(alpha = 0.12f)
            )
        )
    }
}
