package com.pocketlawyer.`in`.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.pocketlawyer.`in`.screens.AboutScreen
import com.pocketlawyer.`in`.screens.ChatScreen
import com.pocketlawyer.`in`.screens.ComplaintScreen
import com.pocketlawyer.`in`.screens.EditProfileScreen
import com.pocketlawyer.`in`.screens.HistoryScreen
import com.pocketlawyer.`in`.screens.HomeScreen
import com.pocketlawyer.`in`.screens.LanguageScreen
import com.pocketlawyer.`in`.screens.NearbyHelpScreen
import com.pocketlawyer.`in`.screens.PrivacyPolicyScreen
import com.pocketlawyer.`in`.screens.ProfileScreen
import com.pocketlawyer.`in`.screens.QuizScreen
import com.pocketlawyer.`in`.screens.RightsDetailScreen
import com.pocketlawyer.`in`.screens.RightsScreen
import com.pocketlawyer.`in`.screens.SosScreen
import com.pocketlawyer.`in`.screens.SosSetupScreen
import com.pocketlawyer.`in`.screens.SplashScreen

@Composable
fun PocketLawyerNavGraph(navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = Destinations.SPLASH) {
        composable(Destinations.SPLASH) { SplashScreen(navController) }
        composable(Destinations.HOME) { HomeScreen(navController) }
        composable(Destinations.CHAT) { ChatScreen(navController) }
        composable(
            Destinations.CHAT_DETAIL,
            arguments = listOf(navArgument("chatId") { type = NavType.IntType })
        ) { backStackEntry ->
            val chatId = backStackEntry.arguments?.getInt("chatId") ?: -1
            ChatScreen(navController, chatId = chatId)
        }
        composable(Destinations.COMPLAINT) { ComplaintScreen(navController) }
        composable(
            Destinations.COMPLAINT_DETAIL,
            arguments = listOf(navArgument("complaintId") { type = NavType.IntType })
        ) { backStackEntry ->
            val complaintId = backStackEntry.arguments?.getInt("complaintId") ?: -1
            ComplaintScreen(navController, complaintId = complaintId)
        }
        composable(Destinations.RIGHTS) { RightsScreen(navController) }
        composable(
            Destinations.RIGHTS_DETAIL,
            arguments = listOf(navArgument("topicId") { type = NavType.StringType })
        ) { backStackEntry ->
            val topicId = backStackEntry.arguments?.getString("topicId") ?: ""
            RightsDetailScreen(navController, topicId)
        }
        composable(Destinations.SOS) { SosScreen(navController) }
        composable(Destinations.SOS_SETUP) { SosSetupScreen(navController) }
        composable(Destinations.NEARBY) { NearbyHelpScreen(navController) }
        composable(Destinations.QUIZ) { QuizScreen(navController) }
        composable(
            Destinations.QUIZ_DETAIL,
            arguments = listOf(navArgument("quizId") { type = NavType.IntType })
        ) { backStackEntry ->
            val quizId = backStackEntry.arguments?.getInt("quizId") ?: -1
            QuizScreen(navController, quizId = quizId)
        }
        composable(Destinations.PROFILE) { ProfileScreen(navController) }
        composable(Destinations.PRIVACY_POLICY) { PrivacyPolicyScreen(navController) }
        composable(Destinations.ABOUT) { AboutScreen(navController) }
        composable(Destinations.EDIT_PROFILE) { EditProfileScreen(navController) }
        composable(Destinations.LANGUAGE) { LanguageScreen(navController) }
        composable(Destinations.HISTORY) { HistoryScreen(navController) }
    }
}
