package com.pocketlawyer.`in`.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.pocketlawyer.`in`.R
import com.pocketlawyer.`in`.screens.common.PLTopBar
import com.pocketlawyer.`in`.ui.theme.PLNavy

@Composable
fun PrivacyPolicyScreen(navController: NavHostController) {
    Scaffold(
        topBar = { PLTopBar(stringResource(R.string.profile_privacy), navController) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            Text(
                "Privacy Policy",
                style = MaterialTheme.typography.headlineSmall,
                color = PLNavy,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 12.dp)
            )
            
            Text(
                "This privacy policy applies to the Pocket Lawyer app for mobile devices, together with any related services (collectively, the \"Application\"). The entity operating the Application is referred to as the \"Service Provider\".",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            PrivacySection("Information Collection and Use", 
                "The Application collects information when you download and use it. This information may include:\n\n" +
                "• Your device's Internet Protocol address\n" +
                "• The pages of the Application that you visit, the time and date of your visit, and the time spent on those pages\n" +
                "• The total time spent on the Application\n" +
                "• The mobile operating system you use"
            )

            PrivacySection("Cookies and tracking technologies", 
                "The Application or its third-party SDKs may use cookies, SDKs, pixels, and similar technologies to support functionality, analytics, or service delivery. Where required by applicable law, the Service Provider will obtain consent before using non-essential tracking technologies."
            )

            PrivacySection("Location Information", 
                "The Application collects your device's location to provide location-based features, improve the Application, and support related services.\n\n" +
                "Geolocation Services: The Service Provider may use location data to provide location-based features or content.\n" +
                "Analytics and Improvements: Aggregated location data may help the Service Provider understand usage patterns and improve performance.\n" +
                "Third-Party Services: Location data may be shared with third-party services used to support Application functionality, subject to this privacy policy and applicable law."
            )

            PrivacySection("Your Rights", 
                "You may request access to, correction of, or deletion of your personal data held by the Service Provider. To exercise these rights, or to withdraw consent where processing is based on consent, please contact the Service Provider."
            )

            PrivacySection("Your California privacy rights (CCPA/CPRA)", 
                "If you are a California resident, you have the right to know what personal information is collected, the right to delete personal information, the right to opt out of the sale or sharing of personal information, and the right to non-discrimination for exercising these rights. To exercise your CCPA/CPRA rights, please contact the Service Provider."
            )

            PrivacySection("Artificial Intelligence", 
                "The Application uses Artificial Intelligence (AI) technologies to enhance user experience and provide certain features. The AI components may process user data to deliver personalized content, recommendations, or automated functionalities. All AI processing is performed in accordance with this privacy policy and applicable laws."
            )

            PrivacySection("Third Party Access", 
                "Only aggregated, anonymized data is periodically transmitted to external services to aid the Service Provider in improving the Application and their service. The Service Provider may share your information with third parties in the ways that are described in this privacy statement."
            )

            PrivacySection("International Data Transfers", 
                "The Service Provider or its third-party service providers may transfer personal data to countries outside your country of residence, including outside the European Economic Area (EEA). Where applicable law requires safeguards for international transfers, the Service Provider will use appropriate mechanisms.\n\n" +
                "• Standard Contractual Clauses (SCCs) approved by the European Commission\n" +
                "• Adequacy decisions or other legally recognized transfer mechanisms\n" +
                "• Your consent, where required and legally permitted"
            )

            PrivacySection("Data Retention Policy", 
                "The Service Provider retains personal data based on its necessity for the stated purposes. You may request deletion of your personal data, subject to any legal obligation to retain it. If you want the Service Provider to delete User Provided Data submitted through the Application, please contact them."
            )

            PrivacySection("Data Deletion", 
                "You can request deletion of your personal data or account by contacting the Service Provider. The Service Provider will process your request within the timeframes required by applicable law."
            )

            PrivacySection("Children", 
                "The Application is not intended for children under 16 years of age. In the event the Service Provider discovers that a child has provided personal information, the Service Provider will immediately delete this from their servers. If you are aware that your child has provided the Service Provider with personal information, please contact the Service Provider."
            )

            PrivacySection("Contact Us", 
                "If you have any questions regarding privacy while using the Application, or have questions about the practices, please contact the Service Provider via email."
            )

            Text(
                "This privacy policy is effective as of 2026-08-26",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.outline,
                modifier = Modifier.padding(vertical = 16.dp)
            )
            
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun PrivacySection(title: String, content: String) {
    Column(modifier = Modifier.padding(bottom = 20.dp)) {
        Text(
            title,
            style = MaterialTheme.typography.titleMedium,
            color = PLNavy,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 6.dp)
        )
        Text(
            content,
            style = MaterialTheme.typography.bodyMedium,
            lineHeight = 22.sp
        )
    }
}
