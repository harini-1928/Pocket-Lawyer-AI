package com.pocketlawyer.`in`.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.sessionDataStore by preferencesDataStore(name = "pocket_lawyer_session")

data class UserSession(
    val name: String?,
    val email: String?,
    val emergencyContact: String? = null,
    val profilePhotoUri: String? = null
) {
    val isLoggedIn: Boolean get() = !email.isNullOrBlank()
    val isGuest: Boolean get() = email == "guest@pocketlawyer.app"
    /** Guest who has not set a custom name yet (so the localized "Guest" text can be shown). */
    val hasDefaultGuestName: Boolean get() = isGuest && (name.isNullOrBlank() || name == "Guest User")
    val firstName: String get() = name?.trim()?.substringBefore(" ")?.takeIf { it.isNotBlank() } ?: "there"
}

private object SessionKeys {
    val NAME = stringPreferencesKey("user_name")
    val EMAIL = stringPreferencesKey("user_email")
    val EMERGENCY_CONTACT = stringPreferencesKey("emergency_contact")
    val PROFILE_PHOTO_URI = stringPreferencesKey("profile_photo_uri")
}

/**
 * Persists user session data including Google account info and emergency contact.
 */
class SessionManager(context: Context) {
    private val appContext = context.applicationContext

    val session: Flow<UserSession> = appContext.sessionDataStore.data.map { prefs ->
        UserSession(
            prefs[SessionKeys.NAME],
            prefs[SessionKeys.EMAIL],
            prefs[SessionKeys.EMERGENCY_CONTACT],
            prefs[SessionKeys.PROFILE_PHOTO_URI]
        )
    }

    suspend fun saveUser(name: String?, email: String?, photoUri: String? = null) {
        appContext.sessionDataStore.edit { prefs ->
            if (!name.isNullOrBlank()) prefs[SessionKeys.NAME] = name
            if (!email.isNullOrBlank()) prefs[SessionKeys.EMAIL] = email
            if (photoUri != null) prefs[SessionKeys.PROFILE_PHOTO_URI] = photoUri
        }
    }

    suspend fun updateProfile(name: String, photoUri: String?) {
        appContext.sessionDataStore.edit { prefs ->
            prefs[SessionKeys.NAME] = name
            if (photoUri != null) {
                prefs[SessionKeys.PROFILE_PHOTO_URI] = photoUri
            }
        }
    }

    suspend fun saveEmergencyContact(number: String) {
        appContext.sessionDataStore.edit { prefs ->
            prefs[SessionKeys.EMERGENCY_CONTACT] = number
        }
    }

    suspend fun clear() {
        appContext.sessionDataStore.edit { it.clear() }
    }
}
