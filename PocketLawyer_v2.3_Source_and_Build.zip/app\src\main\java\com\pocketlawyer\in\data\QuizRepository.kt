package com.pocketlawyer.`in`.data

import com.pocketlawyer.`in`.R

data class QuizQuestion(
    val id: Int,
    val questionRes: Int,
    val optionsRes: List<Int>,
    val correctIndex: Int,
    val explanationRes: Int
)

object QuizRepository {
    val questions: List<QuizQuestion> = listOf(
        QuizQuestion(
            id = 1,
            questionRes = R.string.quiz_q1_text,
            optionsRes = listOf(R.string.quiz_q1_o1, R.string.quiz_q1_o2, R.string.quiz_q1_o3, R.string.quiz_q1_o4),
            correctIndex = 1,
            explanationRes = R.string.quiz_q1_exp
        ),
        QuizQuestion(
            id = 2,
            questionRes = R.string.quiz_q2_text,
            optionsRes = listOf(R.string.quiz_q2_o1, R.string.quiz_q2_o2, R.string.quiz_q2_o3, R.string.quiz_q2_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q2_exp
        ),
        QuizQuestion(
            id = 3,
            questionRes = R.string.quiz_q3_text,
            optionsRes = listOf(R.string.quiz_q3_o1, R.string.quiz_q3_o2, R.string.quiz_q3_o3, R.string.quiz_q3_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q3_exp
        ),
        QuizQuestion(
            id = 4,
            questionRes = R.string.quiz_q4_text,
            optionsRes = listOf(R.string.quiz_q4_o1, R.string.quiz_q4_o2, R.string.quiz_q4_o3, R.string.quiz_q4_o4),
            correctIndex = 1,
            explanationRes = R.string.quiz_q4_exp
        ),
        QuizQuestion(
            id = 5,
            questionRes = R.string.quiz_q5_text,
            optionsRes = listOf(R.string.quiz_q5_o1, R.string.quiz_q5_o2, R.string.quiz_q5_o3, R.string.quiz_q5_o4),
            correctIndex = 1,
            explanationRes = R.string.quiz_q5_exp
        ),
        QuizQuestion(
            id = 6,
            questionRes = R.string.quiz_q6_text,
            optionsRes = listOf(R.string.quiz_q6_o1, R.string.quiz_q6_o2, R.string.quiz_q6_o3, R.string.quiz_q6_o4),
            correctIndex = 1,
            explanationRes = R.string.quiz_q6_exp
        ),
        QuizQuestion(
            id = 7,
            questionRes = R.string.quiz_q7_text,
            optionsRes = listOf(R.string.quiz_q7_o1, R.string.quiz_q7_o2, R.string.quiz_q7_o3, R.string.quiz_q7_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q7_exp
        ),
        QuizQuestion(
            id = 8,
            questionRes = R.string.quiz_q8_text,
            optionsRes = listOf(R.string.quiz_q8_o1, R.string.quiz_q8_o2, R.string.quiz_q8_o3, R.string.quiz_q8_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q8_exp
        ),
        QuizQuestion(
            id = 9,
            questionRes = R.string.quiz_q9_text,
            optionsRes = listOf(R.string.quiz_q9_o1, R.string.quiz_q9_o2, R.string.quiz_q9_o3, R.string.quiz_q9_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q9_exp
        ),
        QuizQuestion(
            id = 10,
            questionRes = R.string.quiz_q10_text,
            optionsRes = listOf(R.string.quiz_q10_o1, R.string.quiz_q10_o2, R.string.quiz_q10_o3, R.string.quiz_q10_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q10_exp
        ),
        QuizQuestion(
            id = 11,
            questionRes = R.string.quiz_q11_text,
            optionsRes = listOf(R.string.quiz_q11_o1, R.string.quiz_q11_o2, R.string.quiz_q11_o3, R.string.quiz_q11_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q11_exp
        ),
        QuizQuestion(
            id = 12,
            questionRes = R.string.quiz_q12_text,
            optionsRes = listOf(R.string.quiz_q12_o1, R.string.quiz_q12_o2, R.string.quiz_q12_o3, R.string.quiz_q12_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q12_exp
        ),
        QuizQuestion(
            id = 13,
            questionRes = R.string.quiz_q13_text,
            optionsRes = listOf(R.string.quiz_q13_o1, R.string.quiz_q13_o2, R.string.quiz_q13_o3, R.string.quiz_q13_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q13_exp
        ),
        QuizQuestion(
            id = 14,
            questionRes = R.string.quiz_q14_text,
            optionsRes = listOf(R.string.quiz_q14_o1, R.string.quiz_q14_o2, R.string.quiz_q14_o3, R.string.quiz_q14_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q14_exp
        ),
        QuizQuestion(
            id = 15,
            questionRes = R.string.quiz_q15_text,
            optionsRes = listOf(R.string.quiz_q15_o1, R.string.quiz_q15_o2, R.string.quiz_q15_o3, R.string.quiz_q15_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q15_exp
        ),
        QuizQuestion(
            id = 16,
            questionRes = R.string.quiz_q16_text,
            optionsRes = listOf(R.string.quiz_q16_o1, R.string.quiz_q16_o2, R.string.quiz_q16_o3, R.string.quiz_q16_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q16_exp
        ),
        QuizQuestion(
            id = 17,
            questionRes = R.string.quiz_q17_text,
            optionsRes = listOf(R.string.quiz_q17_o1, R.string.quiz_q17_o2, R.string.quiz_q17_o3, R.string.quiz_q17_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q17_exp
        ),
        QuizQuestion(
            id = 18,
            questionRes = R.string.quiz_q18_text,
            optionsRes = listOf(R.string.quiz_q18_o1, R.string.quiz_q18_o2, R.string.quiz_q18_o3, R.string.quiz_q18_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q18_exp
        ),
        QuizQuestion(
            id = 19,
            questionRes = R.string.quiz_q19_text,
            optionsRes = listOf(R.string.quiz_q19_o1, R.string.quiz_q19_o2, R.string.quiz_q19_o3, R.string.quiz_q19_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q19_exp
        ),
        QuizQuestion(
            id = 20,
            questionRes = R.string.quiz_q20_text,
            optionsRes = listOf(R.string.quiz_q20_o1, R.string.quiz_q20_o2, R.string.quiz_q20_o3, R.string.quiz_q20_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q20_exp
        ),
        QuizQuestion(
            id = 21,
            questionRes = R.string.quiz_q21_text,
            optionsRes = listOf(R.string.quiz_q21_o1, R.string.quiz_q21_o2, R.string.quiz_q21_o3, R.string.quiz_q21_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q21_exp
        ),
        QuizQuestion(
            id = 22,
            questionRes = R.string.quiz_q22_text,
            optionsRes = listOf(R.string.quiz_q22_o1, R.string.quiz_q22_o2, R.string.quiz_q22_o3, R.string.quiz_q22_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q22_exp
        ),
        QuizQuestion(
            id = 23,
            questionRes = R.string.quiz_q23_text,
            optionsRes = listOf(R.string.quiz_q23_o1, R.string.quiz_q23_o2, R.string.quiz_q23_o3, R.string.quiz_q23_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q23_exp
        ),
        QuizQuestion(
            id = 24,
            questionRes = R.string.quiz_q24_text,
            optionsRes = listOf(R.string.quiz_q24_o1, R.string.quiz_q24_o2, R.string.quiz_q24_o3, R.string.quiz_q24_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q24_exp
        ),
        QuizQuestion(
            id = 25,
            questionRes = R.string.quiz_q25_text,
            optionsRes = listOf(R.string.quiz_q25_o1, R.string.quiz_q25_o2, R.string.quiz_q25_o3, R.string.quiz_q25_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q25_exp
        ),
        QuizQuestion(
            id = 26,
            questionRes = R.string.quiz_q26_text,
            optionsRes = listOf(R.string.quiz_q26_o1, R.string.quiz_q26_o2, R.string.quiz_q26_o3, R.string.quiz_q26_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q26_exp
        ),
        QuizQuestion(
            id = 27,
            questionRes = R.string.quiz_q27_text,
            optionsRes = listOf(R.string.quiz_q27_o1, R.string.quiz_q27_o2, R.string.quiz_q27_o3, R.string.quiz_q27_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q27_exp
        ),
        QuizQuestion(
            id = 28,
            questionRes = R.string.quiz_q28_text,
            optionsRes = listOf(R.string.quiz_q28_o1, R.string.quiz_q28_o2, R.string.quiz_q28_o3, R.string.quiz_q28_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q28_exp
        ),
        QuizQuestion(
            id = 29,
            questionRes = R.string.quiz_q29_text,
            optionsRes = listOf(R.string.quiz_q29_o1, R.string.quiz_q29_o2, R.string.quiz_q29_o3, R.string.quiz_q29_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q29_exp
        ),
        QuizQuestion(
            id = 30,
            questionRes = R.string.quiz_q30_text,
            optionsRes = listOf(R.string.quiz_q30_o1, R.string.quiz_q30_o2, R.string.quiz_q30_o3, R.string.quiz_q30_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q30_exp
        ),
        QuizQuestion(
            id = 31,
            questionRes = R.string.quiz_q31_text,
            optionsRes = listOf(R.string.quiz_q31_o1, R.string.quiz_q31_o2, R.string.quiz_q31_o3, R.string.quiz_q31_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q31_exp
        ),
        QuizQuestion(
            id = 32,
            questionRes = R.string.quiz_q32_text,
            optionsRes = listOf(R.string.quiz_q32_o1, R.string.quiz_q32_o2, R.string.quiz_q32_o3, R.string.quiz_q32_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q32_exp
        ),
        QuizQuestion(
            id = 33,
            questionRes = R.string.quiz_q33_text,
            optionsRes = listOf(R.string.quiz_q33_o1, R.string.quiz_q33_o2, R.string.quiz_q33_o3, R.string.quiz_q33_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q33_exp
        ),
        QuizQuestion(
            id = 34,
            questionRes = R.string.quiz_q34_text,
            optionsRes = listOf(R.string.quiz_q34_o1, R.string.quiz_q34_o2, R.string.quiz_q34_o3, R.string.quiz_q34_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q34_exp
        ),
        QuizQuestion(
            id = 35,
            questionRes = R.string.quiz_q35_text,
            optionsRes = listOf(R.string.quiz_q35_o1, R.string.quiz_q35_o2, R.string.quiz_q35_o3, R.string.quiz_q35_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q35_exp
        ),
        QuizQuestion(
            id = 36,
            questionRes = R.string.quiz_q36_text,
            optionsRes = listOf(R.string.quiz_q36_o1, R.string.quiz_q36_o2, R.string.quiz_q36_o3, R.string.quiz_q36_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q36_exp
        ),
        QuizQuestion(
            id = 37,
            questionRes = R.string.quiz_q37_text,
            optionsRes = listOf(R.string.quiz_q37_o1, R.string.quiz_q37_o2, R.string.quiz_q37_o3, R.string.quiz_q37_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q37_exp
        ),
        QuizQuestion(
            id = 38,
            questionRes = R.string.quiz_q38_text,
            optionsRes = listOf(R.string.quiz_q38_o1, R.string.quiz_q38_o2, R.string.quiz_q38_o3, R.string.quiz_q38_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q38_exp
        ),
        QuizQuestion(
            id = 39,
            questionRes = R.string.quiz_q39_text,
            optionsRes = listOf(R.string.quiz_q39_o1, R.string.quiz_q39_o2, R.string.quiz_q39_o3, R.string.quiz_q39_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q39_exp
        ),
        QuizQuestion(
            id = 40,
            questionRes = R.string.quiz_q40_text,
            optionsRes = listOf(R.string.quiz_q40_o1, R.string.quiz_q40_o2, R.string.quiz_q40_o3, R.string.quiz_q40_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q40_exp
        ),
        QuizQuestion(
            id = 41,
            questionRes = R.string.quiz_q41_text,
            optionsRes = listOf(R.string.quiz_q41_o1, R.string.quiz_q41_o2, R.string.quiz_q41_o3, R.string.quiz_q41_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q41_exp
        ),
        QuizQuestion(
            id = 42,
            questionRes = R.string.quiz_q42_text,
            optionsRes = listOf(R.string.quiz_q42_o1, R.string.quiz_q42_o2, R.string.quiz_q42_o3, R.string.quiz_q42_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q42_exp
        ),
        QuizQuestion(
            id = 43,
            questionRes = R.string.quiz_q43_text,
            optionsRes = listOf(R.string.quiz_q43_o1, R.string.quiz_q43_o2, R.string.quiz_q43_o3, R.string.quiz_q43_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q43_exp
        ),
        QuizQuestion(
            id = 44,
            questionRes = R.string.quiz_q44_text,
            optionsRes = listOf(R.string.quiz_q44_o1, R.string.quiz_q44_o2, R.string.quiz_q44_o3, R.string.quiz_q44_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q44_exp
        ),
        QuizQuestion(
            id = 45,
            questionRes = R.string.quiz_q45_text,
            optionsRes = listOf(R.string.quiz_q45_o1, R.string.quiz_q45_o2, R.string.quiz_q45_o3, R.string.quiz_q45_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q45_exp
        ),
        QuizQuestion(
            id = 46,
            questionRes = R.string.quiz_q46_text,
            optionsRes = listOf(R.string.quiz_q46_o1, R.string.quiz_q46_o2, R.string.quiz_q46_o3, R.string.quiz_q46_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q46_exp
        ),
        QuizQuestion(
            id = 47,
            questionRes = R.string.quiz_q47_text,
            optionsRes = listOf(R.string.quiz_q47_o1, R.string.quiz_q47_o2, R.string.quiz_q47_o3, R.string.quiz_q47_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q47_exp
        ),
        QuizQuestion(
            id = 48,
            questionRes = R.string.quiz_q48_text,
            optionsRes = listOf(R.string.quiz_q48_o1, R.string.quiz_q48_o2, R.string.quiz_q48_o3, R.string.quiz_q48_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q48_exp
        ),
        QuizQuestion(
            id = 49,
            questionRes = R.string.quiz_q49_text,
            optionsRes = listOf(R.string.quiz_q49_o1, R.string.quiz_q49_o2, R.string.quiz_q49_o3, R.string.quiz_q49_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q49_exp
        ),
        QuizQuestion(
            id = 50,
            questionRes = R.string.quiz_q50_text,
            optionsRes = listOf(R.string.quiz_q50_o1, R.string.quiz_q50_o2, R.string.quiz_q50_o3, R.string.quiz_q50_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q50_exp
        ),
        QuizQuestion(
            id = 51,
            questionRes = R.string.quiz_q51_text,
            optionsRes = listOf(R.string.quiz_q51_o1, R.string.quiz_q51_o2, R.string.quiz_q51_o3, R.string.quiz_q51_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q51_exp
        ),
        QuizQuestion(
            id = 52,
            questionRes = R.string.quiz_q52_text,
            optionsRes = listOf(R.string.quiz_q52_o1, R.string.quiz_q52_o2, R.string.quiz_q52_o3, R.string.quiz_q52_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q52_exp
        ),
        QuizQuestion(
            id = 53,
            questionRes = R.string.quiz_q53_text,
            optionsRes = listOf(R.string.quiz_q53_o1, R.string.quiz_q53_o2, R.string.quiz_q53_o3, R.string.quiz_q53_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q53_exp
        ),
        QuizQuestion(
            id = 54,
            questionRes = R.string.quiz_q54_text,
            optionsRes = listOf(R.string.quiz_q54_o1, R.string.quiz_q54_o2, R.string.quiz_q54_o3, R.string.quiz_q54_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q54_exp
        ),
        QuizQuestion(
            id = 55,
            questionRes = R.string.quiz_q55_text,
            optionsRes = listOf(R.string.quiz_q55_o1, R.string.quiz_q55_o2, R.string.quiz_q55_o3, R.string.quiz_q55_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q55_exp
        ),
        QuizQuestion(
            id = 56,
            questionRes = R.string.quiz_q56_text,
            optionsRes = listOf(R.string.quiz_q56_o1, R.string.quiz_q56_o2, R.string.quiz_q56_o3, R.string.quiz_q56_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q56_exp
        ),
        QuizQuestion(
            id = 57,
            questionRes = R.string.quiz_q57_text,
            optionsRes = listOf(R.string.quiz_q57_o1, R.string.quiz_q57_o2, R.string.quiz_q57_o3, R.string.quiz_q57_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q57_exp
        ),
        QuizQuestion(
            id = 58,
            questionRes = R.string.quiz_q58_text,
            optionsRes = listOf(R.string.quiz_q58_o1, R.string.quiz_q58_o2, R.string.quiz_q58_o3, R.string.quiz_q58_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q58_exp
        ),
        QuizQuestion(
            id = 59,
            questionRes = R.string.quiz_q59_text,
            optionsRes = listOf(R.string.quiz_q59_o1, R.string.quiz_q59_o2, R.string.quiz_q59_o3, R.string.quiz_q59_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q59_exp
        ),
        QuizQuestion(
            id = 60,
            questionRes = R.string.quiz_q60_text,
            optionsRes = listOf(R.string.quiz_q60_o1, R.string.quiz_q60_o2, R.string.quiz_q60_o3, R.string.quiz_q60_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q60_exp
        ),
        QuizQuestion(
            id = 61,
            questionRes = R.string.quiz_q61_text,
            optionsRes = listOf(R.string.quiz_q61_o1, R.string.quiz_q61_o2, R.string.quiz_q61_o3, R.string.quiz_q61_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q61_exp
        ),
        QuizQuestion(
            id = 62,
            questionRes = R.string.quiz_q62_text,
            optionsRes = listOf(R.string.quiz_q62_o1, R.string.quiz_q62_o2, R.string.quiz_q62_o3, R.string.quiz_q62_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q62_exp
        ),
        QuizQuestion(
            id = 63,
            questionRes = R.string.quiz_q63_text,
            optionsRes = listOf(R.string.quiz_q63_o1, R.string.quiz_q63_o2, R.string.quiz_q63_o3, R.string.quiz_q63_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q63_exp
        ),
        QuizQuestion(
            id = 64,
            questionRes = R.string.quiz_q64_text,
            optionsRes = listOf(R.string.quiz_q64_o1, R.string.quiz_q64_o2, R.string.quiz_q64_o3, R.string.quiz_q64_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q64_exp
        ),
        QuizQuestion(
            id = 65,
            questionRes = R.string.quiz_q65_text,
            optionsRes = listOf(R.string.quiz_q65_o1, R.string.quiz_q65_o2, R.string.quiz_q65_o3, R.string.quiz_q65_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q65_exp
        ),
        QuizQuestion(
            id = 66,
            questionRes = R.string.quiz_q66_text,
            optionsRes = listOf(R.string.quiz_q66_o1, R.string.quiz_q66_o2, R.string.quiz_q66_o3, R.string.quiz_q66_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q66_exp
        ),
        QuizQuestion(
            id = 67,
            questionRes = R.string.quiz_q67_text,
            optionsRes = listOf(R.string.quiz_q67_o1, R.string.quiz_q67_o2, R.string.quiz_q67_o3, R.string.quiz_q67_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q67_exp
        ),
        QuizQuestion(
            id = 68,
            questionRes = R.string.quiz_q68_text,
            optionsRes = listOf(R.string.quiz_q68_o1, R.string.quiz_q68_o2, R.string.quiz_q68_o3, R.string.quiz_q68_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q68_exp
        ),
        QuizQuestion(
            id = 69,
            questionRes = R.string.quiz_q69_text,
            optionsRes = listOf(R.string.quiz_q69_o1, R.string.quiz_q69_o2, R.string.quiz_q69_o3, R.string.quiz_q69_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q69_exp
        ),
        QuizQuestion(
            id = 70,
            questionRes = R.string.quiz_q70_text,
            optionsRes = listOf(R.string.quiz_q70_o1, R.string.quiz_q70_o2, R.string.quiz_q70_o3, R.string.quiz_q70_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q70_exp
        ),
        QuizQuestion(
            id = 71,
            questionRes = R.string.quiz_q71_text,
            optionsRes = listOf(R.string.quiz_q71_o1, R.string.quiz_q71_o2, R.string.quiz_q71_o3, R.string.quiz_q71_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q71_exp
        ),
        QuizQuestion(
            id = 72,
            questionRes = R.string.quiz_q72_text,
            optionsRes = listOf(R.string.quiz_q72_o1, R.string.quiz_q72_o2, R.string.quiz_q72_o3, R.string.quiz_q72_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q72_exp
        ),
        QuizQuestion(
            id = 73,
            questionRes = R.string.quiz_q73_text,
            optionsRes = listOf(R.string.quiz_q73_o1, R.string.quiz_q73_o2, R.string.quiz_q73_o3, R.string.quiz_q73_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q73_exp
        ),
        QuizQuestion(
            id = 74,
            questionRes = R.string.quiz_q74_text,
            optionsRes = listOf(R.string.quiz_q74_o1, R.string.quiz_q74_o2, R.string.quiz_q74_o3, R.string.quiz_q74_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q74_exp
        ),
        QuizQuestion(
            id = 75,
            questionRes = R.string.quiz_q75_text,
            optionsRes = listOf(R.string.quiz_q75_o1, R.string.quiz_q75_o2, R.string.quiz_q75_o3, R.string.quiz_q75_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q75_exp
        ),
        QuizQuestion(
            id = 76,
            questionRes = R.string.quiz_q76_text,
            optionsRes = listOf(R.string.quiz_q76_o1, R.string.quiz_q76_o2, R.string.quiz_q76_o3, R.string.quiz_q76_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q76_exp
        ),
        QuizQuestion(
            id = 77,
            questionRes = R.string.quiz_q77_text,
            optionsRes = listOf(R.string.quiz_q77_o1, R.string.quiz_q77_o2, R.string.quiz_q77_o3, R.string.quiz_q77_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q77_exp
        ),
        QuizQuestion(
            id = 78,
            questionRes = R.string.quiz_q78_text,
            optionsRes = listOf(R.string.quiz_q78_o1, R.string.quiz_q78_o2, R.string.quiz_q78_o3, R.string.quiz_q78_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q78_exp
        ),
        QuizQuestion(
            id = 79,
            questionRes = R.string.quiz_q79_text,
            optionsRes = listOf(R.string.quiz_q79_o1, R.string.quiz_q79_o2, R.string.quiz_q79_o3, R.string.quiz_q79_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q79_exp
        ),
        QuizQuestion(
            id = 80,
            questionRes = R.string.quiz_q80_text,
            optionsRes = listOf(R.string.quiz_q80_o1, R.string.quiz_q80_o2, R.string.quiz_q80_o3, R.string.quiz_q80_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q80_exp
        ),
        QuizQuestion(
            id = 81,
            questionRes = R.string.quiz_q81_text,
            optionsRes = listOf(R.string.quiz_q81_o1, R.string.quiz_q81_o2, R.string.quiz_q81_o3, R.string.quiz_q81_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q81_exp
        ),
        QuizQuestion(
            id = 82,
            questionRes = R.string.quiz_q82_text,
            optionsRes = listOf(R.string.quiz_q82_o1, R.string.quiz_q82_o2, R.string.quiz_q82_o3, R.string.quiz_q82_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q82_exp
        ),
        QuizQuestion(
            id = 83,
            questionRes = R.string.quiz_q83_text,
            optionsRes = listOf(R.string.quiz_q83_o1, R.string.quiz_q83_o2, R.string.quiz_q83_o3, R.string.quiz_q83_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q83_exp
        ),
        QuizQuestion(
            id = 84,
            questionRes = R.string.quiz_q84_text,
            optionsRes = listOf(R.string.quiz_q84_o1, R.string.quiz_q84_o2, R.string.quiz_q84_o3, R.string.quiz_q84_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q84_exp
        ),
        QuizQuestion(
            id = 85,
            questionRes = R.string.quiz_q85_text,
            optionsRes = listOf(R.string.quiz_q85_o1, R.string.quiz_q85_o2, R.string.quiz_q85_o3, R.string.quiz_q85_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q85_exp
        ),
        QuizQuestion(
            id = 86,
            questionRes = R.string.quiz_q86_text,
            optionsRes = listOf(R.string.quiz_q86_o1, R.string.quiz_q86_o2, R.string.quiz_q86_o3, R.string.quiz_q86_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q86_exp
        ),
        QuizQuestion(
            id = 87,
            questionRes = R.string.quiz_q87_text,
            optionsRes = listOf(R.string.quiz_q87_o1, R.string.quiz_q87_o2, R.string.quiz_q87_o3, R.string.quiz_q87_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q87_exp
        ),
        QuizQuestion(
            id = 88,
            questionRes = R.string.quiz_q88_text,
            optionsRes = listOf(R.string.quiz_q88_o1, R.string.quiz_q88_o2, R.string.quiz_q88_o3, R.string.quiz_q88_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q88_exp
        ),
        QuizQuestion(
            id = 89,
            questionRes = R.string.quiz_q89_text,
            optionsRes = listOf(R.string.quiz_q89_o1, R.string.quiz_q89_o2, R.string.quiz_q89_o3, R.string.quiz_q89_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q89_exp
        ),
        QuizQuestion(
            id = 90,
            questionRes = R.string.quiz_q90_text,
            optionsRes = listOf(R.string.quiz_q90_o1, R.string.quiz_q90_o2, R.string.quiz_q90_o3, R.string.quiz_q90_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q90_exp
        ),
        QuizQuestion(
            id = 91,
            questionRes = R.string.quiz_q91_text,
            optionsRes = listOf(R.string.quiz_q91_o1, R.string.quiz_q91_o2, R.string.quiz_q91_o3, R.string.quiz_q91_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q91_exp
        ),
        QuizQuestion(
            id = 92,
            questionRes = R.string.quiz_q92_text,
            optionsRes = listOf(R.string.quiz_q92_o1, R.string.quiz_q92_o2, R.string.quiz_q92_o3, R.string.quiz_q92_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q92_exp
        ),
        QuizQuestion(
            id = 93,
            questionRes = R.string.quiz_q93_text,
            optionsRes = listOf(R.string.quiz_q93_o1, R.string.quiz_q93_o2, R.string.quiz_q93_o3, R.string.quiz_q93_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q93_exp
        ),
        QuizQuestion(
            id = 94,
            questionRes = R.string.quiz_q94_text,
            optionsRes = listOf(R.string.quiz_q94_o1, R.string.quiz_q94_o2, R.string.quiz_q94_o3, R.string.quiz_q94_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q94_exp
        ),
        QuizQuestion(
            id = 95,
            questionRes = R.string.quiz_q95_text,
            optionsRes = listOf(R.string.quiz_q95_o1, R.string.quiz_q95_o2, R.string.quiz_q95_o3, R.string.quiz_q95_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q95_exp
        ),
        QuizQuestion(
            id = 96,
            questionRes = R.string.quiz_q96_text,
            optionsRes = listOf(R.string.quiz_q96_o1, R.string.quiz_q96_o2, R.string.quiz_q96_o3, R.string.quiz_q96_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q96_exp
        ),
        QuizQuestion(
            id = 97,
            questionRes = R.string.quiz_q97_text,
            optionsRes = listOf(R.string.quiz_q97_o1, R.string.quiz_q97_o2, R.string.quiz_q97_o3, R.string.quiz_q97_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q97_exp
        ),
        QuizQuestion(
            id = 98,
            questionRes = R.string.quiz_q98_text,
            optionsRes = listOf(R.string.quiz_q98_o1, R.string.quiz_q98_o2, R.string.quiz_q98_o3, R.string.quiz_q98_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q98_exp
        ),
        QuizQuestion(
            id = 99,
            questionRes = R.string.quiz_q99_text,
            optionsRes = listOf(R.string.quiz_q99_o1, R.string.quiz_q99_o2, R.string.quiz_q99_o3, R.string.quiz_q99_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q99_exp
        ),
        QuizQuestion(
            id = 100,
            questionRes = R.string.quiz_q100_text,
            optionsRes = listOf(R.string.quiz_q100_o1, R.string.quiz_q100_o2, R.string.quiz_q100_o3, R.string.quiz_q100_o4),
            correctIndex = 0,
            explanationRes = R.string.quiz_q100_exp
        )
    )

    fun getRandomQuiz(count: Int = 5): List<QuizQuestion> {
        return questions.shuffled().take(count)
    }
}
