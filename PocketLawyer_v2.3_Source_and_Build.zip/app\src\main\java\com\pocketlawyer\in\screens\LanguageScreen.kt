package com.pocketlawyer.`in`.screens

import android.app.Activity
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.os.LocaleListCompat
import androidx.navigation.NavHostController
import com.pocketlawyer.`in`.R
import com.pocketlawyer.`in`.screens.common.PLTopBar
import com.pocketlawyer.`in`.ui.theme.PLNavy

private data class LanguageOption(val label: String, val tag: String)

private val languages = listOf(
    LanguageOption("English", "en"),
    LanguageOption("தமிழ் (Tamil)", "ta"),
    LanguageOption("हिंदी (Hindi)", "hi")
)

@Composable
fun LanguageScreen(navController: NavHostController) {
    val context = LocalContext.current
    var selected by remember {
        mutableStateOf(
            AppCompatDelegate.getApplicationLocales().toLanguageTags().takeIf { it.isNotBlank() } ?: "en"
        )
    }

    Scaffold(topBar = { PLTopBar(stringResource(R.string.language_title), navController) }) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
            Text(
                stringResource(R.string.language_choose),
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(bottom = 14.dp)
            )

            languages.forEach { lang ->
                val isSelected = selected == lang.tag
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp)
                        .clickable { selected = lang.tag },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(lang.label, style = MaterialTheme.typography.bodyLarge)
                        Icon(
                            if (isSelected) Icons.Filled.CheckCircle else Icons.Outlined.Circle,
                            contentDescription = null,
                            tint = if (isSelected) PLNavy else MaterialTheme.colorScheme.outline
                        )
                    }
                }
            }

            Button(
                onClick = {
                    val localeList = LocaleListCompat.forLanguageTags(selected)
                    AppCompatDelegate.setApplicationLocales(localeList)
                    (context as? Activity)?.recreate()
                    navController.popBackStack()
                },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp).padding(top = 12.dp)
            ) { Text(stringResource(R.string.save)) }
        }
    }
}
