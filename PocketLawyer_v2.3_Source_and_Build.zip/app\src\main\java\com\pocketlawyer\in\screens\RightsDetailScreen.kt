package com.pocketlawyer.`in`.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.pocketlawyer.`in`.R
import com.pocketlawyer.`in`.screens.common.PLTopBar
import com.pocketlawyer.`in`.ui.theme.PLNavy
import com.pocketlawyer.`in`.ui.theme.PLTextSecondary

@Composable
fun RightsDetailScreen(navController: NavHostController, topicId: String) {
    val context = LocalContext.current
    val topic = rightsTopicById(topicId)

    Scaffold(topBar = { PLTopBar(topic?.let { stringResource(it.titleRes) } ?: stringResource(R.string.rights_title), navController) }) { padding ->
        if (topic == null) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text(stringResource(R.string.rights_topic_not_found))
            }
            return@Scaffold
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .background(PLNavy.copy(alpha = 0.08f)),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier.size(72.dp).background(PLNavy, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(topic.icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(34.dp))
                }
            }

            Column(modifier = Modifier.fillMaxWidth().padding(20.dp)) {
                Text(stringResource(topic.headingRes), style = MaterialTheme.typography.titleLarge)
                Text(
                    stringResource(topic.descriptionRes),
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(top = 10.dp)
                )

                Text(
                    stringResource(R.string.rights_key_points),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(top = 22.dp, bottom = 10.dp)
                )
                topic.keyPointsRes.forEach { pointRes ->
                    Row(modifier = Modifier.padding(bottom = 8.dp)) {
                        Icon(
                            Icons.Filled.Circle,
                            contentDescription = null,
                            tint = PLNavy,
                            modifier = Modifier.size(7.dp).padding(top = 7.dp)
                        )
                        Text(
                            stringResource(pointRes),
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.padding(start = 10.dp)
                        )
                    }
                }

                Text(
                    stringResource(topic.lawRes),
                    style = MaterialTheme.typography.bodyMedium,
                    color = PLTextSecondary,
                    modifier = Modifier.padding(top = 12.dp, bottom = 24.dp)
                )

                Button(
                    onClick = {
                        val heading = context.getString(topic.headingRes)
                        val desc = context.getString(topic.descriptionRes)
                        val points = topic.keyPointsRes.map { context.getString(it) }
                        val law = context.getString(topic.lawRes)
                        
                        val shareText = "$heading\n\n$desc\n\n" +
                            points.joinToString("\n") { "• $it" } +
                            "\n\n$law\n\n— via Pocket Lawyer app"
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, shareText)
                        }
                        context.startActivity(Intent.createChooser(intent, context.getString(R.string.share)))
                    },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) {
                    Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.padding(end = 8.dp))
                    Text(stringResource(R.string.complaint_share))
                }
            }
        }
    }
}
