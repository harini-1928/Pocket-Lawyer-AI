package com.pocketlawyer.`in`.network

/**
 * Centralized configuration for the Google Gemini API (direct connection).
 *
 * Models are tried in order. If the first one is unavailable (retired, overloaded or over quota)
 * the chat automatically falls back to the next one.
 * Stable models as listed on ai.google.dev (Sept 2026): gemini-3.5-flash, gemini-3.6-flash,
 * gemini-3.5-flash-lite, gemini-3.1-flash-lite.
 */
object ApiConfig {
    // Primary model (kept for logging / error messages)
    const val GEMINI_MODEL = "gemini-3.6-flash"

    // Order in which models are attempted
    val MODELS = listOf(
        "gemini-3.6-flash",
        "gemini-3.5-flash",
        "gemini-3.5-flash-lite",
        "gemini-3.1-flash-lite"
    )

    const val BASE_URL = "https://generativelanguage.googleapis.com/"

    // Retry settings (per model, for temporary errors such as 429 / 5xx)
    const val MAX_RETRIES = 2
    const val INITIAL_BACKOFF_MS = 1000L
}
