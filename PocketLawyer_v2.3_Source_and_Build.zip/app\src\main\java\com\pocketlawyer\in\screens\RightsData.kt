package com.pocketlawyer.`in`.screens

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Wc
import androidx.compose.material.icons.filled.Work
import androidx.compose.ui.graphics.vector.ImageVector
import com.pocketlawyer.`in`.R

data class RightsTopic(
    val id: String,
    val titleRes: Int,
    val subtitleRes: Int,
    val icon: ImageVector,
    val headingRes: Int,
    val descriptionRes: Int,
    val keyPointsRes: List<Int>,
    val lawRes: Int
)

val rightsTopics = listOf(
    RightsTopic(
        id = "consumer",
        titleRes = R.string.rights_consumer_title,
        subtitleRes = R.string.rights_consumer_sub,
        icon = Icons.Filled.ShoppingCart,
        headingRes = R.string.rights_consumer_heading,
        descriptionRes = R.string.rights_consumer_desc,
        keyPointsRes = listOf(
            R.string.rights_consumer_p1,
            R.string.rights_consumer_p2,
            R.string.rights_consumer_p3
        ),
        lawRes = R.string.rights_consumer_law
    ),
    RightsTopic(
        id = "women",
        titleRes = R.string.rights_women_title,
        subtitleRes = R.string.rights_women_sub,
        icon = Icons.Filled.Wc,
        headingRes = R.string.rights_women_heading,
        descriptionRes = R.string.rights_women_desc,
        keyPointsRes = listOf(
            R.string.rights_women_p1,
            R.string.rights_women_p2,
            R.string.rights_women_p3
        ),
        lawRes = R.string.rights_women_law
    ),
    RightsTopic(
        id = "employee",
        titleRes = R.string.rights_employee_title,
        subtitleRes = R.string.rights_employee_sub,
        icon = Icons.Filled.Work,
        headingRes = R.string.rights_employee_heading,
        descriptionRes = R.string.rights_employee_desc,
        keyPointsRes = listOf(
            R.string.rights_employee_p1,
            R.string.rights_employee_p2,
            R.string.rights_employee_p3
        ),
        lawRes = R.string.rights_employee_law
    ),
    RightsTopic(
        id = "cyber",
        titleRes = R.string.rights_cyber_title,
        subtitleRes = R.string.rights_cyber_sub,
        icon = Icons.Filled.Security,
        headingRes = R.string.rights_cyber_heading,
        descriptionRes = R.string.rights_cyber_desc,
        keyPointsRes = listOf(
            R.string.rights_cyber_p1,
            R.string.rights_cyber_p2,
            R.string.rights_cyber_p3
        ),
        lawRes = R.string.rights_cyber_law
    ),
    RightsTopic(
        id = "traffic",
        titleRes = R.string.rights_traffic_title,
        subtitleRes = R.string.rights_traffic_sub,
        icon = Icons.Filled.DirectionsCar,
        headingRes = R.string.rights_traffic_heading,
        descriptionRes = R.string.rights_traffic_desc,
        keyPointsRes = listOf(
            R.string.rights_traffic_p1,
            R.string.rights_traffic_p2,
            R.string.rights_traffic_p3
        ),
        lawRes = R.string.rights_traffic_law
    ),
    RightsTopic(
        id = "tenant",
        titleRes = R.string.rights_tenant_title,
        subtitleRes = R.string.rights_tenant_sub,
        icon = Icons.Filled.Home,
        headingRes = R.string.rights_tenant_heading,
        descriptionRes = R.string.rights_tenant_desc,
        keyPointsRes = listOf(
            R.string.rights_tenant_p1,
            R.string.rights_tenant_p2,
            R.string.rights_tenant_p3
        ),
        lawRes = R.string.rights_tenant_law
    ),
    RightsTopic(
        id = "privacy",
        titleRes = R.string.rights_privacy_title,
        subtitleRes = R.string.rights_privacy_sub,
        icon = Icons.Filled.Lock,
        headingRes = R.string.rights_privacy_heading,
        descriptionRes = R.string.rights_privacy_desc,
        keyPointsRes = listOf(
            R.string.rights_privacy_p1,
            R.string.rights_privacy_p2,
            R.string.rights_privacy_p3
        ),
        lawRes = R.string.rights_privacy_law
    )
)

fun rightsTopicById(id: String): RightsTopic? = rightsTopics.firstOrNull { it.id == id }
