package com.pocketlawyer.`in`.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.pocketlawyer.`in`.R
import com.pocketlawyer.`in`.screens.common.BottomTab
import com.pocketlawyer.`in`.screens.common.PLBottomBar
import com.pocketlawyer.`in`.ui.theme.PLGold
import com.pocketlawyer.`in`.ui.theme.PLNavy
import com.pocketlawyer.`in`.ui.theme.PLTextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(navController: NavHostController, viewModel: HistoryViewModel = viewModel()) {
    val chats by viewModel.chats.collectAsState(initial = emptyList())
    val complaints by viewModel.complaints.collectAsState(initial = emptyList())
    val quizzes by viewModel.quizzes.collectAsState(initial = emptyList())

    val allItems = remember(chats, complaints, quizzes) {
        try {
            (chats.map { HistoryItem.Chat(it) } +
             complaints.map { HistoryItem.Complaint(it) } +
             quizzes.map { HistoryItem.Quiz(it) }
            ).sortedByDescending { it.timestamp }
        } catch (e: Exception) {
            android.util.Log.e("HistoryScreen", "Error processing history items", e)
            emptyList()
        }
    }

    Scaffold(bottomBar = { PLBottomBar(navController, BottomTab.HISTORY) }) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            Text(
                stringResource(R.string.history_title),
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(20.dp)
            )

            if (allItems.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.History, contentDescription = null, tint = PLTextSecondary, modifier = Modifier.size(48.dp))
                        Text(stringResource(R.string.history_empty_title), style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp))
                        Text(
                            stringResource(R.string.history_empty_desc),
                            style = MaterialTheme.typography.bodyMedium,
                            color = PLTextSecondary,
                            modifier = Modifier.padding(top = 6.dp, start = 40.dp, end = 40.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(allItems) { item ->
                        HistoryCard(item) {
                            when (item) {
                                is HistoryItem.Chat -> {
                                    navController.navigate(com.pocketlawyer.`in`.navigation.Destinations.chatDetail(item.data.id))
                                }
                                is HistoryItem.Complaint -> {
                                    navController.navigate(com.pocketlawyer.`in`.navigation.Destinations.complaintDetail(item.data.id))
                                }
                                is HistoryItem.Quiz -> {
                                    navController.navigate(com.pocketlawyer.`in`.navigation.Destinations.quizDetail(item.data.id))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HistoryCard(item: HistoryItem, onClick: () -> Unit) {
    val config = when (item) {
        is HistoryItem.Chat -> HistoryCardConfig(
            stringResource(R.string.history_type_chat), 
            item.data.query, 
            Icons.AutoMirrored.Filled.Chat, 
            PLNavy
        )
        is HistoryItem.Complaint -> HistoryCardConfig(
            stringResource(R.string.history_type_complaint), 
            item.data.type, 
            Icons.Filled.Gavel, 
            Color(0xFF4CAF50)
        )
        is HistoryItem.Quiz -> HistoryCardConfig(
            stringResource(R.string.history_type_quiz), 
            stringResource(R.string.history_quiz_score, item.data.score, item.data.total), 
            Icons.Filled.Quiz, 
            PLGold
        )
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(40.dp).background(config.color.copy(alpha = 0.1f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(config.icon, contentDescription = null, tint = config.color, modifier = Modifier.size(20.dp))
            }
            Column(modifier = Modifier.padding(start = 14.dp).weight(1f)) {
                Text(config.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text(
                    config.sub, 
                    style = MaterialTheme.typography.bodySmall, 
                    color = PLTextSecondary,
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
            }
            Text(
                formatDate(item.timestamp), 
                style = MaterialTheme.typography.bodySmall, 
                color = PLTextSecondary
            )
        }
    }
}

private fun formatDate(time: Long): String {
    val sdf = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault())
    return sdf.format(Date(time))
}

private data class HistoryCardConfig(
    val title: String,
    val sub: String,
    val icon: ImageVector,
    val color: Color
)
