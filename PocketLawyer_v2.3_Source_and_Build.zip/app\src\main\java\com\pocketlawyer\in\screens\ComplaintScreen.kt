package com.pocketlawyer.`in`.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.pocketlawyer.`in`.R
import com.pocketlawyer.`in`.screens.common.PLStepper
import com.pocketlawyer.`in`.screens.common.PLTopBar
import com.pocketlawyer.`in`.ui.theme.PLNavy
import com.pocketlawyer.`in`.ui.theme.PLTextSecondary
import com.pocketlawyer.`in`.util.PdfGenerator
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class ComplaintTypeOption(val titleRes: Int, val id: String)

private val complaintTypes = listOf(
    ComplaintTypeOption(R.string.complaint_type_police, "police"),
    ComplaintTypeOption(R.string.complaint_type_cyber, "cyber"),
    ComplaintTypeOption(R.string.complaint_type_consumer, "consumer"),
    ComplaintTypeOption(R.string.complaint_type_workplace, "workplace"),
    ComplaintTypeOption(R.string.complaint_type_landlord, "landlord")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ComplaintScreen(
    navController: NavHostController, 
    viewModel: ComplaintViewModel = viewModel(),
    complaintId: Int = -1
) {
    val context = LocalContext.current
    val isHistoryMode = complaintId != -1
    var step by remember { mutableIntStateOf(if (isHistoryMode) 4 else 1) }

    var selectedType by remember { mutableStateOf(complaintTypes.first()) }
    var date by remember { mutableStateOf("") }
    var showDatePicker by remember { mutableStateOf(false) }
    val datePickerState = rememberDatePickerState()

    var location by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var generatedPath by remember { mutableStateOf<String?>(null) }

    // Sync with ViewModel state for history
    if (isHistoryMode) {
        LaunchedEffect(complaintId) {
            viewModel.loadComplaintHistory(complaintId)
        }
        
        // Populate local states when ViewModel finishes loading
        if (!viewModel.isLoading.value) {
            val historyType = complaintTypes.find { it.id == viewModel.selectedTypeId.value }
            if (historyType != null) selectedType = historyType
            date = viewModel.date.value
            location = viewModel.location.value
            name = viewModel.name.value
            description = viewModel.description.value
        }
    }

    Scaffold(topBar = { 
        PLTopBar(
            if (isHistoryMode) stringResource(R.string.complaint_review_type) + " " + stringResource(R.string.history_title) 
            else stringResource(R.string.complaint_title), 
            navController
        ) 
    }) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            if (!isHistoryMode) {
                PLStepper(totalSteps = 4, currentStep = step)
            }

            when (step) {
                1 -> {
                    Text(stringResource(R.string.complaint_step_1), style = MaterialTheme.typography.titleMedium)
                    Column(modifier = Modifier.padding(top = 14.dp)) {
                        complaintTypes.forEach { option ->
                            val isSelected = selectedType.id == option.id
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 10.dp)
                                    .clickable { selectedType = option },
                                shape = RoundedCornerShape(14.dp),
                                border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, PLNavy) else null,
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(stringResource(option.titleRes), style = MaterialTheme.typography.bodyLarge)
                                    if (isSelected) {
                                        Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = PLNavy)
                                    }
                                }
                            }
                        }
                    }
                }
                2 -> {
                    Text(stringResource(R.string.complaint_step_2), style = MaterialTheme.typography.titleMedium)
                    Column(modifier = Modifier.padding(top = 14.dp)) {
                        if (showDatePicker) {
                            DatePickerDialog(
                                onDismissRequest = { showDatePicker = false },
                                confirmButton = {
                                    TextButton(onClick = {
                                        datePickerState.selectedDateMillis?.let { millis ->
                                            val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                                            date = sdf.format(Date(millis))
                                        }
                                        showDatePicker = false
                                    }) {
                                        Text(stringResource(android.R.string.ok))
                                    }
                                },
                                dismissButton = {
                                    TextButton(onClick = { showDatePicker = false }) {
                                        Text(stringResource(android.R.string.cancel))
                                    }
                                }
                            ) {
                                DatePicker(state = datePickerState)
                            }
                        }

                        OutlinedTextField(
                            value = date,
                            onValueChange = { },
                            readOnly = true,
                            enabled = false,
                            label = { Text(stringResource(R.string.complaint_incident_date)) },
                            placeholder = { Text(stringResource(R.string.complaint_date_hint)) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showDatePicker = true },
                            colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                                disabledTextColor = MaterialTheme.colorScheme.onSurface,
                                disabledBorderColor = MaterialTheme.colorScheme.outline,
                                disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                disabledPlaceholderColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                        Box(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = location, onValueChange = { location = it },
                            label = { Text(stringResource(R.string.complaint_location)) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
                3 -> {
                    Text(stringResource(R.string.complaint_step_3), style = MaterialTheme.typography.titleMedium)
                    Column(modifier = Modifier.padding(top = 14.dp)) {
                        OutlinedTextField(
                            value = name, onValueChange = { name = it },
                            label = { Text(stringResource(R.string.complaint_name)) },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Box(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = description, onValueChange = { description = it },
                            label = { Text(stringResource(R.string.complaint_description)) },
                            modifier = Modifier.fillMaxWidth().height(150.dp)
                        )
                    }
                }
                4 -> {
                    Text(stringResource(R.string.complaint_step_4), style = MaterialTheme.typography.titleMedium)
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(top = 14.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            ReviewRow(stringResource(R.string.complaint_review_type), stringResource(selectedType.titleRes))
                            ReviewRow(stringResource(R.string.complaint_review_date), date.ifBlank { "—" })
                            ReviewRow(stringResource(R.string.complaint_review_location), location.ifBlank { "—" })
                            ReviewRow(stringResource(R.string.complaint_review_name), name.ifBlank { "—" })
                            ReviewRow(stringResource(R.string.complaint_review_description), description.ifBlank { "—" })
                        }
                    }

                    if (!isHistoryMode) {
                        Button(
                            onClick = {
                                viewModel.generateAndSave(
                                    context, selectedType.id, date, location, description, name
                                ) { file ->
                                    generatedPath = file.absolutePath
                                }
                            },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().height(52.dp).padding(top = 18.dp)
                        ) { Text(stringResource(R.string.complaint_generate)) }
                    }

                    if (generatedPath != null || isHistoryMode) {
                        if (!isHistoryMode) {
                            Text(
                                stringResource(R.string.complaint_generated_msg),
                                style = MaterialTheme.typography.bodyMedium,
                                color = PLTextSecondary,
                                modifier = Modifier.padding(top = 10.dp)
                            )
                        }
                        
                        // Sharing only works if we have the file, which history mode doesn't store (only text).
                        // In a real app we'd regenerate or save the PDF path.
                        // For now, in history mode, we just show the summary.
                        if (generatedPath != null) {
                            Button(
                                onClick = {
                                    val sourceFile = java.io.File(generatedPath!!)
                                    val downloadedFile = PdfGenerator.downloadToPublicFolder(context, sourceFile)
                                    val msg = if (downloadedFile != null) {
                                        "Complaint PDF downloaded to Downloads folder!"
                                    } else {
                                        "Saved PDF in app storage."
                                    }
                                    android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_LONG).show()
                                },
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth().height(52.dp).padding(top = 10.dp)
                            ) {
                                Text("Download PDF")
                            }

                            OutlinedButton(
                                onClick = {
                                    val file = java.io.File(generatedPath!!)
                                    val uri = PdfGenerator.shareUriForFile(context, file)
                                    val intent = Intent(Intent.ACTION_SEND).apply {
                                        type = "application/pdf"
                                        putExtra(Intent.EXTRA_STREAM, uri)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(Intent.createChooser(intent, "Share complaint letter"))
                                },
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth().height(52.dp).padding(top = 10.dp)
                            ) { Text(stringResource(R.string.complaint_share)) }
                        }
                    }
                }
            }

            if (!isHistoryMode) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    if (step > 1) {
                        OutlinedButton(onClick = { step-- }, shape = RoundedCornerShape(14.dp)) {
                            Text(stringResource(R.string.back))
                        }
                    } else {
                        Box {}
                    }
                    if (step < 4) {
                        Button(onClick = { step++ }, shape = RoundedCornerShape(14.dp)) {
                            Text(stringResource(R.string.next))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ReviewRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = PLTextSecondary)
        Text(value, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(start = 12.dp))
    }
}
