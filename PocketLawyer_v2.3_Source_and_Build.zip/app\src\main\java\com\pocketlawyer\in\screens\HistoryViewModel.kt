package com.pocketlawyer.`in`.screens

import android.app.Application
import androidx.annotation.Keep
import androidx.lifecycle.AndroidViewModel
import com.pocketlawyer.`in`.data.ChatHistory
import com.pocketlawyer.`in`.data.ComplaintHistory
import com.pocketlawyer.`in`.data.PocketLawyerDatabase
import com.pocketlawyer.`in`.data.QuizHistory
import kotlinx.coroutines.flow.Flow

@Keep
sealed class HistoryItem {
    abstract val timestamp: Long
    
    @Keep
    data class Chat(val data: ChatHistory) : HistoryItem() {
        override val timestamp = data.timestamp
    }
    @Keep
    data class Complaint(val data: ComplaintHistory) : HistoryItem() {
        override val timestamp = data.timestamp
    }
    @Keep
    data class Quiz(val data: QuizHistory) : HistoryItem() {
        override val timestamp = data.timestamp
    }
}

class HistoryViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = PocketLawyerDatabase.getDatabase(application).historyDao()

    val chats: Flow<List<ChatHistory>> = dao.getAllChats()
    val complaints: Flow<List<ComplaintHistory>> = dao.getAllComplaints()
    val quizzes: Flow<List<QuizHistory>> = dao.getAllQuizzes()

    init {
        android.util.Log.d("HistoryViewModel", "HistoryViewModel initialized.")
    }
}
