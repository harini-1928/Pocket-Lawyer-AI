package com.pocketlawyer.`in`

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.pocketlawyer.`in`.navigation.PocketLawyerNavGraph
import com.pocketlawyer.`in`.ui.theme.PocketLawyerTheme

// Extends AppCompatActivity (rather than plain ComponentActivity) so that
// AppCompatDelegate.setApplicationLocales() in LanguageScreen reliably switches the
// in-app language on devices below Android 13, not just on 13+.
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PocketLawyerTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    PocketLawyerNavGraph()
                }
            }
        }
    }
}
