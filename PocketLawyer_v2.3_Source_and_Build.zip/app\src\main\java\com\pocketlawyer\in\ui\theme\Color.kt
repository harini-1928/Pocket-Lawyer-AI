package com.pocketlawyer.`in`.ui.theme

import androidx.compose.ui.graphics.Color

// Matches the Pocket Lawyer prototype palette
val PLNavyDark = Color(0xFF141E46)     // deepest navy (splash gradient end)
val PLNavy = Color(0xFF1B2A6B)         // primary navy (top bars, buttons, cards)
val PLNavyLight = Color(0xFF2A3E8C)    // lighter navy accent
val PLGold = Color(0xFFC89B3C)         // secondary accent
val PLGreen = Color(0xFF27AE60)        // success / correct-answer green
val PLRed = Color(0xFFE0473E)          // SOS red
val PLBackground = Color(0xFFF5F6FA)   // light screen background
val PLSurface = Color(0xFFFFFFFF)
val PLTextPrimary = Color(0xFF1B1F3B)
val PLTextSecondary = Color(0xFF6B7280)
val PLChipBackground = Color(0xFFEDEFF7)
