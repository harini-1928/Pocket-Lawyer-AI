package com.pocketlawyer.`in`.navigation

object Destinations {
    const val SPLASH = "splash"
    const val HOME = "home"
    const val CHAT = "chat"
    const val CHAT_DETAIL = "chat_detail/{chatId}"
    const val COMPLAINT = "complaint"
    const val COMPLAINT_DETAIL = "complaint_detail/{complaintId}"
    const val RIGHTS = "rights"
    const val RIGHTS_DETAIL = "rights_detail/{topicId}"
    const val SOS = "sos"
    const val SOS_SETUP = "sos_setup"
    const val NEARBY = "nearby"
    const val QUIZ = "quiz"
    const val QUIZ_DETAIL = "quiz_detail/{quizId}"
    const val PROFILE = "profile"
    const val EDIT_PROFILE = "edit_profile"
    const val LANGUAGE = "language"
    const val HISTORY = "history"
    const val ABOUT = "about"
    const val PRIVACY_POLICY = "privacy_policy"

    fun rightsDetail(topicId: String) = "rights_detail/$topicId"
    fun chatDetail(chatId: Int) = "chat_detail/$chatId"
    fun complaintDetail(id: Int) = "complaint_detail/$id"
    fun quizDetail(id: Int) = "quiz_detail/$id"
}
