package com.pocketlawyer.`in`.util

import android.util.Base64
import com.pocketlawyer.`in`.BuildConfig

object SecretUtils {
    fun getApiKey(): String {
        return try {
            val decodedBytes = Base64.decode(BuildConfig.AI_API_KEY_B64, Base64.DEFAULT)
            String(decodedBytes, Charsets.UTF_8)
        } catch (e: Exception) {
            ""
        }
    }
}
