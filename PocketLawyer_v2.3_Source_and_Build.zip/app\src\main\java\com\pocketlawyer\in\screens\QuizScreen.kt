package com.pocketlawyer.`in`.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.pocketlawyer.`in`.R
import com.pocketlawyer.`in`.data.QuizRepository
import com.pocketlawyer.`in`.screens.common.PLTopBar
import com.pocketlawyer.`in`.ui.theme.PLGreen
import com.pocketlawyer.`in`.ui.theme.PLNavy
import com.pocketlawyer.`in`.ui.theme.PLRed
import com.pocketlawyer.`in`.ui.theme.PLTextSecondary

@Composable
fun QuizScreen(
    navController: NavHostController, 
    viewModel: QuizViewModel = viewModel(),
    quizId: Int = -1
) {
    val isHistoryMode = quizId != -1
    var trialSeed by remember { mutableIntStateOf(0) }
    var index by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var selectedOption by remember { mutableIntStateOf(-1) }
    var finished by remember { mutableIntStateOf(if (isHistoryMode) 1 else 0) }
    var answered by remember { mutableIntStateOf(0) }

    // Pick 5 random questions from the 100-question pool whenever trialSeed changes
    val activeQuestions = remember(trialSeed) {
        QuizRepository.getRandomQuiz(5)
    }

    if (isHistoryMode) {
        LaunchedEffect(quizId) {
            viewModel.loadQuizHistory(quizId)
        }
        score = viewModel.historyScore.intValue
    }

    Scaffold(topBar = { 
        PLTopBar(
            if (isHistoryMode) stringResource(R.string.quiz_title) + " " + stringResource(R.string.history_title)
            else stringResource(R.string.quiz_title), 
            navController
        ) 
    }) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
            if (finished == 1) {
                // SAVE SCORE ONCE (if not history mode)
                if (!isHistoryMode) {
                    LaunchedEffect(Unit) {
                        viewModel.saveScore(score, activeQuestions.size)
                    }
                }
                
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
                ) {
                    Text(
                        stringResource(
                            R.string.quiz_result_score, 
                            if (isHistoryMode) viewModel.historyScore.intValue else score, 
                            if (isHistoryMode) viewModel.historyTotal.intValue else activeQuestions.size
                        ), 
                        style = MaterialTheme.typography.titleLarge
                    )
                    
                    if (!isHistoryMode) {
                        Spacer(modifier = Modifier.padding(top = 16.dp))
                        Button(onClick = {
                            trialSeed++
                            index = 0
                            score = 0
                            selectedOption = -1
                            finished = 0
                            answered = 0
                        }) { Text(stringResource(R.string.quiz_restart)) }
                    }
                }
            } else {
                val q = activeQuestions[index]
                Text(stringResource(R.string.quiz_question_count, index + 1, activeQuestions.size), style = MaterialTheme.typography.bodyMedium, color = PLTextSecondary)
                Text(stringResource(q.questionRes), style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp, bottom = 16.dp))

                q.optionsRes.forEachIndexed { i, optionRes ->
                    val isCorrect = i == q.correctIndex
                    val isSelected = selectedOption == i
                    val showState = answered == 1

                    val borderColor = when {
                        showState && isCorrect -> PLGreen
                        showState && isSelected && !isCorrect -> PLRed
                        else -> MaterialTheme.colorScheme.surfaceVariant
                    }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp)
                            .clickable(enabled = answered == 0) {
                                selectedOption = i
                                answered = 1
                            },
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, borderColor),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(stringResource(optionRes), style = MaterialTheme.typography.bodyLarge)
                            if (showState && isCorrect) {
                                Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = PLGreen)
                            } else if (showState && isSelected && !isCorrect) {
                                Icon(Icons.Filled.Cancel, contentDescription = null, tint = PLRed)
                            }
                        }
                    }
                }

                if (answered == 1) {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = PLGreen.copy(alpha = 0.08f))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                if (selectedOption == q.correctIndex) stringResource(R.string.quiz_feedback_correct) else stringResource(R.string.quiz_feedback_wrong),
                                style = MaterialTheme.typography.titleSmall,
                                color = if (selectedOption == q.correctIndex) PLGreen else PLRed
                            )
                            Text(
                                stringResource(q.explanationRes),
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }

                    Button(
                        onClick = {
                            if (selectedOption == q.correctIndex) score++
                            if (index == activeQuestions.lastIndex) {
                                finished = 1
                            } else {
                                index++
                                selectedOption = -1
                                answered = 0
                            }
                        },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
                    ) {
                        Text(if (index == activeQuestions.lastIndex) stringResource(R.string.quiz_finish) else stringResource(R.string.quiz_next))
                    }
                }
            }
        }
    }
}
