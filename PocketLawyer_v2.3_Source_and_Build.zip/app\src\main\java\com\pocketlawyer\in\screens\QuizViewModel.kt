package com.pocketlawyer.`in`.screens

import android.app.Application
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pocketlawyer.`in`.data.PocketLawyerDatabase
import com.pocketlawyer.`in`.data.QuizHistory
import kotlinx.coroutines.launch

class QuizViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = PocketLawyerDatabase.getDatabase(application).historyDao()

    val historyScore = mutableIntStateOf(0)
    val historyTotal = mutableIntStateOf(0)
    val isLoading = mutableStateOf(false)

    fun saveScore(score: Int, total: Int) {
        viewModelScope.launch {
            dao.insertQuiz(QuizHistory(
                timestamp = System.currentTimeMillis(),
                score = score,
                total = total
            ))
        }
    }

    fun loadQuizHistory(id: Int) {
        if (id == -1) return
        viewModelScope.launch {
            isLoading.value = true
            val history = dao.getQuizById(id)
            if (history != null) {
                historyScore.intValue = history.score
                historyTotal.intValue = history.total
            }
            isLoading.value = false
        }
    }
}
