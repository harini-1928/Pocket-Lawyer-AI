package com.pocketlawyer.`in`.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.LocalPolice
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Scale
import androidx.compose.material.icons.filled.Woman
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.navigation.NavHostController
import com.pocketlawyer.`in`.R
import com.pocketlawyer.`in`.screens.common.PLTopBar
import com.pocketlawyer.`in`.ui.theme.PLNavy
import com.pocketlawyer.`in`.ui.theme.PLRed
import com.pocketlawyer.`in`.ui.theme.PLTextSecondary

private data class HelpCategory(
    val titleRes: Int,
    val searchQuery: String,
    val icon: ImageVector,
    val helpline: String,
    val helplineLabel: String,
    val descriptionRes: Int
)

private val categories = listOf(
    HelpCategory(
        R.string.nearby_police_stations, 
        "police station", 
        Icons.Filled.LocalPolice, 
        "100", 
        "Police Helpline (100)",
        R.string.nearby_police_desc
    ),
    HelpCategory(
        R.string.nearby_legal_aid_centers, 
        "legal aid center", 
        Icons.Filled.Scale, 
        "15100", 
        "NALSA Helpline (15100)",
        R.string.nearby_legal_aid_desc
    ),
    HelpCategory(
        R.string.nearby_women_support_centers, 
        "one stop center women helpline", 
        Icons.Filled.Woman, 
        "1091", 
        "Women Helpline (1091)",
        R.string.nearby_women_desc
    ),
    HelpCategory(
        R.string.nearby_courts, 
        "district court consumer court", 
        Icons.Filled.Gavel, 
        "1800-11-4000", 
        "Consumer Helpline",
        R.string.nearby_courts_desc
    )
)

@Composable
fun NearbyHelpScreen(navController: NavHostController) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) }
    var hasLocationPermission by remember { 
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        hasLocationPermission = results[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                                results[Manifest.permission.ACCESS_COARSE_LOCATION] == true
    }

    LaunchedEffect(Unit) {
        if (!hasLocationPermission) {
            permissionLauncher.launch(arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ))
        }
    }

    Scaffold(topBar = { PLTopBar(stringResource(R.string.nearby_title), navController) }) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = PLNavy,
                edgePadding = 16.dp
            ) {
                categories.forEachIndexed { i, cat ->
                    Tab(
                        selected = selectedTab == i,
                        onClick = { selectedTab = i },
                        text = { Text(stringResource(cat.titleRes)) }
                    )
                }
            }

            val currentCat = categories[selectedTab]
            val catTitle = stringResource(currentCat.titleRes)

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    // ACTION CARD
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = PLNavy),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier.size(48.dp).background(Color.White.copy(alpha = 0.2f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(currentCat.icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                                }
                                Spacer(Modifier.size(16.dp))
                                Text(
                                    stringResource(R.string.nearby_find_button, catTitle),
                                    color = Color.White,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            
                            Text(
                                stringResource(currentCat.descriptionRes),
                                color = Color.White.copy(alpha = 0.8f),
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(top = 12.dp)
                            )

                            Button(
                                onClick = {
                                    val uri = Uri.parse("geo:0,0?q=" + Uri.encode(currentCat.searchQuery))
                                    val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                                        setPackage("com.google.android.apps.maps")
                                    }
                                    try {
                                        context.startActivity(intent)
                                    } catch (e: Exception) {
                                        // Fallback to generic geo intent if Google Maps isn't installed
                                        context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().padding(top = 20.dp).height(48.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = PLNavy),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Filled.Navigation, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.size(8.dp))
                                Text(stringResource(R.string.nearby_open_maps), fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }

                item {
                    // HELPLINE CARD
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(stringResource(R.string.nearby_immediate_assistance), style = MaterialTheme.typography.labelMedium, color = PLTextSecondary)
                                Text(
                                    currentCat.helplineLabel,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(top = 2.dp)
                                )
                            }
                            
                            Button(
                                onClick = {
                                    context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${currentCat.helpline}")))
                                },
                                shape = CircleShape,
                                colors = ButtonDefaults.buttonColors(containerColor = PLRed),
                                modifier = Modifier.size(44.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Icon(Icons.Filled.Call, contentDescription = "Call", tint = Color.White, modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                }

                item {
                    // INFO CARD
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(PLNavy.copy(alpha = 0.05f), RoundedCornerShape(12.dp))
                            .padding(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.Top) {
                            Icon(Icons.Filled.LocationOn, contentDescription = null, tint = PLNavy, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.size(12.dp))
                            Text(
                                if (hasLocationPermission) stringResource(R.string.nearby_location_active) 
                                else stringResource(R.string.nearby_location_inactive),
                                style = MaterialTheme.typography.bodySmall,
                                color = PLTextSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}
