package com.pocketlawyer.`in`.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContactPhone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.pocketlawyer.`in`.R
import com.pocketlawyer.`in`.data.UserSession
import com.pocketlawyer.`in`.navigation.Destinations
import com.pocketlawyer.`in`.ui.theme.PLGold
import com.pocketlawyer.`in`.ui.theme.PLNavy
import com.pocketlawyer.`in`.ui.theme.PLNavyDark

@Composable
fun SosSetupScreen(navController: NavHostController, viewModel: LoginViewModel = viewModel()) {
    val session by viewModel.session.collectAsState(initial = UserSession(null, null))
    var contactNumber by remember(session.emergencyContact) { 
        mutableStateOf(session.emergencyContact?.filter { it.isDigit() }?.take(10) ?: "") 
    }

    val isValid10DigitMobile = contactNumber.length == 10 && contactNumber.all { it.isDigit() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(PLNavy, PLNavyDark)))
            .imePadding() // Key for keyboard handling
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(28.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            Spacer(modifier = Modifier.height(40.dp))
            
            Box(
                modifier = Modifier.size(96.dp).background(Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.ContactPhone, contentDescription = null, tint = PLNavy, modifier = Modifier.size(48.dp))
            }

            Text(
                stringResource(R.string.sos_title),
                color = Color.White,
                style = MaterialTheme.typography.headlineSmall,
                modifier = Modifier.padding(top = 24.dp)
            )
            
            Text(
                stringResource(R.string.sos_setup_desc),
                color = PLGold,
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 12.dp)
            )

            OutlinedTextField(
                value = contactNumber,
                onValueChange = { newValue ->
                    // Strictly accept digits only and max 10 digits
                    val digits = newValue.filter { it.isDigit() }.take(10)
                    contactNumber = digits
                },
                textStyle = TextStyle(color = Color.White, fontSize = 18.sp),
                label = { Text(stringResource(R.string.sos_setup_number_label), color = Color.White.copy(alpha = 0.8f)) },
                supportingText = {
                    if (contactNumber.isNotBlank() && !isValid10DigitMobile) {
                        Text(
                            "Please enter a valid 10-digit mobile number (${contactNumber.length}/10)",
                            color = Color(0xFFFF8A80)
                        )
                    }
                },
                isError = contactNumber.isNotBlank() && !isValid10DigitMobile,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(top = 32.dp),
                shape = RoundedCornerShape(14.dp),
                colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = Color.White,
                    unfocusedBorderColor = Color.White.copy(alpha = 0.6f),
                    errorBorderColor = Color(0xFFFF8A80),
                    cursorColor = PLGold
                )
            )

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = { 
                    if (isValid10DigitMobile) {
                        viewModel.saveEmergencyContact(contactNumber) {
                            if (!navController.popBackStack()) {
                                navController.navigate(Destinations.HOME)
                            }
                        }
                    }
                },
                enabled = isValid10DigitMobile,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White, 
                    contentColor = PLNavy,
                    disabledContainerColor = Color.White.copy(alpha = 0.4f),
                    disabledContentColor = PLNavy.copy(alpha = 0.4f)
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Text(stringResource(R.string.sos_setup_save), style = MaterialTheme.typography.labelLarge)
            }
            
            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}
