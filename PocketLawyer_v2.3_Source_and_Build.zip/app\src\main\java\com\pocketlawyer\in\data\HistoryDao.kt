package com.pocketlawyer.`in`.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface HistoryDao {
    @Query("SELECT * FROM chat_history ORDER BY timestamp DESC")
    fun getAllChats(): Flow<List<ChatHistory>>

    @Query("SELECT * FROM chat_history WHERE id = :id")
    suspend fun getChatById(id: Int): ChatHistory?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChat(chat: ChatHistory)

    @Query("SELECT * FROM complaint_history ORDER BY timestamp DESC")
    fun getAllComplaints(): Flow<List<ComplaintHistory>>

    @Query("SELECT * FROM complaint_history WHERE id = :id")
    suspend fun getComplaintById(id: Int): ComplaintHistory?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComplaint(complaint: ComplaintHistory)

    @Query("SELECT * FROM quiz_history ORDER BY timestamp DESC")
    fun getAllQuizzes(): Flow<List<QuizHistory>>

    @Query("SELECT * FROM quiz_history WHERE id = :id")
    suspend fun getQuizById(id: Int): QuizHistory?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuiz(quiz: QuizHistory)
}
