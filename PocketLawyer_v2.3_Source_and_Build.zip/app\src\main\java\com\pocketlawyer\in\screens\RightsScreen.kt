package com.pocketlawyer.`in`.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.pocketlawyer.`in`.R
import com.pocketlawyer.`in`.navigation.Destinations
import com.pocketlawyer.`in`.screens.common.BottomTab
import com.pocketlawyer.`in`.screens.common.PLBottomBar
import com.pocketlawyer.`in`.screens.common.PLTopBar
import com.pocketlawyer.`in`.ui.theme.PLNavy
import com.pocketlawyer.`in`.ui.theme.PLTextSecondary

@Composable
fun RightsScreen(navController: NavHostController) {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    val filtered = remember(query) {
        rightsTopics.filter { topic ->
            context.getString(topic.titleRes).contains(query, ignoreCase = true) ||
                    context.getString(topic.subtitleRes).contains(query, ignoreCase = true)
        }
    }

    Scaffold(
        topBar = { PLTopBar(stringResource(R.string.rights_title), navController) },
        bottomBar = { PLBottomBar(navController, BottomTab.HOME) }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text(stringResource(R.string.rights_search_placeholder)) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(),
                modifier = Modifier.fillMaxWidth()
            )

            LazyColumn(modifier = Modifier.padding(top = 12.dp)) {
                items(filtered) { topic ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 5.dp)
                            .clickable { navController.navigate(Destinations.rightsDetail(topic.id)) },
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier.size(40.dp).background(PLNavy.copy(alpha = 0.1f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(topic.icon, contentDescription = null, tint = PLNavy)
                                }
                                Column(modifier = Modifier.padding(start = 12.dp)) {
                                    Text(stringResource(topic.titleRes), style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        stringResource(topic.subtitleRes),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = PLTextSecondary
                                    )
                                }
                            }
                            Icon(
                                Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                contentDescription = null,
                                tint = PLTextSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}
