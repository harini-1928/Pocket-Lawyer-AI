package com.pocketlawyer.`in`.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [ChatHistory::class, ComplaintHistory::class, QuizHistory::class], version = 2)
abstract class PocketLawyerDatabase : RoomDatabase() {
    abstract fun historyDao(): HistoryDao

    companion object {
        @Volatile
        private var INSTANCE: PocketLawyerDatabase? = null

        fun getDatabase(context: Context): PocketLawyerDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PocketLawyerDatabase::class.java,
                    "pocket_lawyer_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
