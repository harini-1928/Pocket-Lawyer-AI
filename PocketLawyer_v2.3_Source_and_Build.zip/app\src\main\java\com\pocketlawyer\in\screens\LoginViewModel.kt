package com.pocketlawyer.`in`.screens

import android.app.Application
import android.content.Context
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialException
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import com.pocketlawyer.`in`.BuildConfig
import com.pocketlawyer.`in`.data.SessionManager
import com.pocketlawyer.`in`.data.UserSession
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.security.SecureRandom
import android.util.Base64

class LoginViewModel(application: Application) : AndroidViewModel(application) {
    private val sessionManager = SessionManager(application)
    val session: kotlinx.coroutines.flow.Flow<UserSession> = sessionManager.session

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage

    fun clearError() {
        _errorMessage.value = null
    }

    /** Launches the Google Sign-In sheet and, on success, persists the account name/email. */
    fun signInWithGoogle(context: Context, onSuccess: () -> Unit) {
        if (BuildConfig.GOOGLE_WEB_CLIENT_ID.isBlank()) {
            _errorMessage.value = "Google Sign-In isn't configured yet. Add your OAuth Web " +
                "Client ID to GOOGLE_WEB_CLIENT_ID in app/build.gradle (see README)."
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            try {
                val credentialManager = CredentialManager.create(context)
                val nonce = generateNonce()
                
                // Use GetGoogleIdOption configured to show all Google accounts
                val googleIdOption = GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(BuildConfig.GOOGLE_WEB_CLIENT_ID)
                    .setNonce(nonce)
                    .setAutoSelectEnabled(false)
                    .build()

                val request = GetCredentialRequest.Builder()
                    .addCredentialOption(googleIdOption)
                    .build()

                val result = try {
                    credentialManager.getCredential(context, request)
                } catch (e: GetCredentialException) {
                    // Fallback to GetSignInWithGoogleOption
                    val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = BuildConfig.GOOGLE_WEB_CLIENT_ID)
                        .setNonce(nonce)
                        .build()
                    val fallbackRequest = GetCredentialRequest.Builder()
                        .addCredentialOption(signInOption)
                        .build()
                    credentialManager.getCredential(context, fallbackRequest)
                }

                val googleCredential = GoogleIdTokenCredential.createFrom(result.credential.data)

                val userEmail = googleCredential.id.takeIf { !it.isNullOrBlank() } ?: "user@pocketlawyer.in"
                val userName = googleCredential.displayName.takeIf { !it.isNullOrBlank() } 
                    ?: googleCredential.givenName 
                    ?: userEmail.substringBefore("@").replaceFirstChar { char -> char.uppercase() }
                val photoUri = googleCredential.profilePictureUri?.toString()

                sessionManager.saveUser(userName, userEmail, photoUri)
                _isLoading.value = false
                onSuccess()
            } catch (e: GetCredentialException) {
                _isLoading.value = false
                val type = e.type.orEmpty()
                if (type.contains("TYPE_USER_CANCELED", ignoreCase = true) ||
                    type.contains("UserCanceledException", ignoreCase = true) ||
                    type.contains("USER_CANCELED", ignoreCase = true)) {
                    // User dismissed the sheet
                    _errorMessage.value = null
                } else if (type.contains("DEVELOPER_ERROR", ignoreCase = true) || (e.message ?: "").contains("10", ignoreCase = true)) {
                    _errorMessage.value = "Google Sign-In configuration error: Check SHA-1 fingerprint and OAuth Web Client ID in Google Cloud Console, or continue as Guest."
                } else if (type.contains("TYPE_NO_CREDENTIAL", ignoreCase = true) || type.contains("NoCredentialException", ignoreCase = true)) {
                    _errorMessage.value = "No Google account found on device. Add a Google account in Android Settings or continue as Guest."
                } else {
                    _errorMessage.value = "Sign-in error: ${e.message ?: "Please try again or continue as Guest."}"
                    android.util.Log.e("LoginViewModel", "GetCredentialException: ${e.message}", e)
                }
            } catch (e: GoogleIdTokenParsingException) {
                _isLoading.value = false
                _errorMessage.value = "Couldn't read Google account details. Please try again or continue as Guest."
            } catch (e: Exception) {
                _isLoading.value = false
                _errorMessage.value = "Sign-in failed: ${e.message ?: "Unknown error"}. You can continue as Guest."
            }
        }
    }

    /** Bypasses Google Sign-In and signs the user in with a dummy local account. */
    fun signInAsGuest(onSuccess: () -> Unit) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            // Dummy data for guest session
            sessionManager.saveUser("Guest User", "guest@pocketlawyer.app")
            _isLoading.value = false
            onSuccess()
        }
    }

    fun saveEmergencyContact(number: String, onDone: () -> Unit) {
        viewModelScope.launch {
            sessionManager.saveEmergencyContact(number)
            onDone()
        }
    }

    fun updateProfile(name: String, photoUri: String?, onDone: () -> Unit) {
        viewModelScope.launch {
            sessionManager.updateProfile(name, photoUri)
            onDone()
        }
    }

    /** Signs the user out locally and clears the saved Google credential state. */
    fun signOut(context: Context, onDone: () -> Unit) {
        viewModelScope.launch {
            try {
                CredentialManager.create(context).clearCredentialState(ClearCredentialStateRequest())
            } catch (_: Exception) {
                // Non-fatal — proceed to clear local session regardless.
            }
            sessionManager.clear()
            onDone()
        }
    }

    private fun generateNonce(): String {
        val randomBytes = ByteArray(32)
        SecureRandom().nextBytes(randomBytes)
        return Base64.encodeToString(randomBytes, Base64.NO_WRAP or Base64.URL_SAFE or Base64.NO_PADDING)
    }
}
