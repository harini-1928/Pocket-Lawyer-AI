package com.pocketlawyer.`in`.data

import androidx.annotation.Keep
import androidx.room.Entity
import androidx.room.PrimaryKey

@Keep
@Entity(tableName = "chat_history")
data class ChatHistory(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long,
    val query: String,
    val response: String
)

@Keep
@Entity(tableName = "complaint_history")
data class ComplaintHistory(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long,
    val type: String,
    val typeId: String,
    val date: String,
    val location: String,
    val name: String,
    val description: String
)

@Keep
@Entity(tableName = "quiz_history")
data class QuizHistory(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long,
    val score: Int,
    val total: Int
)
