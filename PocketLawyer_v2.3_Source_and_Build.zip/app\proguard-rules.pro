# Add project specific ProGuard rules here.
-keep class com.pocketlawyer.in.data.** { *; }
-keep class com.pocketlawyer.in.network.** { *; }

# Credential Manager & Google Sign-In Library Keep Rules
-keep class androidx.credentials.** { *; }
-keep class com.google.android.libraries.identity.googleid.** { *; }
-keep class com.google.android.gms.auth.api.** { *; }
-keep class com.google.android.gms.common.** { *; }

# Keep ViewModel and Compose related classes
-keepclassmembers class * extends androidx.lifecycle.ViewModel {
    public <init>(...);
}

-keep class androidx.compose.ui.** { *; }
-keep class androidx.compose.material3.** { *; }

# Strip debug logs in release builds
-assumenosideeffects class android.util.Log {
    public static int v(...);
    public static int d(...);
    public static int i(...);
}

