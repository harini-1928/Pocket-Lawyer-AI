package com.pocketlawyer.`in`.screens

import android.app.Application
import android.content.Context
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pocketlawyer.`in`.data.ComplaintHistory
import com.pocketlawyer.`in`.data.PocketLawyerDatabase
import com.pocketlawyer.`in`.util.PdfGenerator
import kotlinx.coroutines.launch
import java.io.File

class ComplaintViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = PocketLawyerDatabase.getDatabase(application).historyDao()

    // Observables for state management (especially for history viewing)
    val selectedTypeId = mutableStateOf("police")
    val date = mutableStateOf("")
    val location = mutableStateOf("")
    val name = mutableStateOf("")
    val description = mutableStateOf("")
    val isLoading = mutableStateOf(false)

    fun generateAndSave(
        context: Context,
        typeId: String,
        dateStr: String,
        locationStr: String,
        descriptionStr: String,
        nameStr: String,
        onResult: (File) -> Unit
    ) {
        viewModelScope.launch {
            val file = PdfGenerator.generateComplaintPdf(
                context, typeId, dateStr, locationStr, descriptionStr, nameStr
            )
            
            val typeTitle = context.getString(when(typeId) {
                "police" -> com.pocketlawyer.`in`.R.string.complaint_type_police
                "cyber" -> com.pocketlawyer.`in`.R.string.complaint_type_cyber
                "consumer" -> com.pocketlawyer.`in`.R.string.complaint_type_consumer
                "workplace" -> com.pocketlawyer.`in`.R.string.complaint_type_workplace
                "landlord" -> com.pocketlawyer.`in`.R.string.complaint_type_landlord
                else -> com.pocketlawyer.`in`.R.string.complaint_type_other
            })

            dao.insertComplaint(ComplaintHistory(
                timestamp = System.currentTimeMillis(),
                type = typeTitle,
                typeId = typeId,
                date = dateStr,
                location = locationStr,
                name = nameStr,
                description = descriptionStr
            ))
            
            onResult(file)
        }
    }

    fun loadComplaintHistory(id: Int) {
        if (id == -1) return
        viewModelScope.launch {
            isLoading.value = true
            val history = dao.getComplaintById(id)
            if (history != null) {
                selectedTypeId.value = history.typeId
                date.value = history.date
                location.value = history.location
                name.value = history.name
                description.value = history.description
            }
            isLoading.value = false
        }
    }
}
