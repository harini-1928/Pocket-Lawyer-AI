package com.pocketlawyer.`in`.util

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfGenerator {

    // Maps each complaint type to the authority it should formally be addressed to.
    private fun recipientFor(context: Context, typeId: String): String = context.getString(when (typeId) {
        "police" -> com.pocketlawyer.`in`.R.string.pdf_recipient_police
        "cyber" -> com.pocketlawyer.`in`.R.string.pdf_recipient_cyber
        "consumer" -> com.pocketlawyer.`in`.R.string.pdf_recipient_consumer
        "workplace" -> com.pocketlawyer.`in`.R.string.pdf_recipient_workplace
        "landlord" -> com.pocketlawyer.`in`.R.string.pdf_recipient_landlord
        else -> com.pocketlawyer.`in`.R.string.complaint_type_other
    })

    private fun subjectFor(context: Context, typeId: String): String = context.getString(when (typeId) {
        "police" -> com.pocketlawyer.`in`.R.string.pdf_subject_police
        "cyber" -> com.pocketlawyer.`in`.R.string.pdf_subject_cyber
        "consumer" -> com.pocketlawyer.`in`.R.string.pdf_subject_consumer
        "workplace" -> com.pocketlawyer.`in`.R.string.pdf_subject_workplace
        "landlord" -> com.pocketlawyer.`in`.R.string.pdf_subject_landlord
        else -> com.pocketlawyer.`in`.R.string.pdf_subject_default
    })

    fun generateComplaintPdf(
        context: Context,
        typeId: String,
        incidentDate: String,
        location: String,
        description: String,
        complainantName: String
    ): File {
        val document = PdfDocument()
        val pageWidth = 595   // A4 at 72dpi
        val pageHeight = 842
        val marginLeft = 56f
        val marginRight = 56f
        val contentWidth = pageWidth - marginLeft - marginRight

        var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        var page = document.startPage(pageInfo)
        var canvas = page.canvas

        val titlePaint = Paint().apply { textSize = 12f; typeface = Typeface.DEFAULT_BOLD }
        val bodyPaint = Paint().apply { textSize = 12f; typeface = Typeface.DEFAULT }
        val boldPaint = Paint().apply { textSize = 12f; typeface = Typeface.DEFAULT_BOLD }
        val smallPaint = Paint().apply { textSize = 9f; typeface = Typeface.DEFAULT; color = android.graphics.Color.GRAY }

        val today = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()).format(Date())
        var y = 70f
        val lineHeight = 18f
        val paraGap = 10f

        fun newPageIfNeeded(needed: Float) {
            if (y + needed > pageHeight - 70f) {
                document.finishPage(page)
                pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, document.pages.size + 1).create()
                page = document.startPage(pageInfo)
                canvas = page.canvas
                y = 60f
            }
        }

        fun drawParagraph(text: String, paint: Paint, extraGapAfter: Float = paraGap) {
            val words = text.split(" ")
            var line = StringBuilder()
            for (word in words) {
                val testLine = if (line.isEmpty()) word else "$line $word"
                if (paint.measureText(testLine) > contentWidth) {
                    newPageIfNeeded(lineHeight)
                    canvas.drawText(line.toString(), marginLeft, y, paint)
                    y += lineHeight
                    line = StringBuilder(word)
                } else {
                    line = StringBuilder(testLine)
                }
            }
            if (line.isNotEmpty()) {
                newPageIfNeeded(lineHeight)
                canvas.drawText(line.toString(), marginLeft, y, paint)
                y += lineHeight
            }
            y += extraGapAfter
        }

        fun drawMultilineBlock(text: String, paint: Paint) {
            text.split("\n").forEach { line ->
                newPageIfNeeded(lineHeight)
                canvas.drawText(line, marginLeft, y, paint)
                y += lineHeight
            }
        }

        // Date, top-right aligned
        val dateLine = context.getString(com.pocketlawyer.`in`.R.string.pdf_date_prefix) + today
        val dateWidth = bodyPaint.measureText(dateLine)
        canvas.drawText(dateLine, pageWidth - marginRight - dateWidth, y, bodyPaint)
        y += lineHeight + paraGap

        // Recipient block
        canvas.drawText(context.getString(com.pocketlawyer.`in`.R.string.pdf_to_prefix), marginLeft, y, bodyPaint)
        y += lineHeight
        drawMultilineBlock(recipientFor(context, typeId), bodyPaint)
        if (location.isNotBlank()) {
            canvas.drawText(location, marginLeft, y, bodyPaint)
            y += lineHeight
        }
        y += paraGap

        // Subject
        newPageIfNeeded(lineHeight * 2)
        val subjectLine = context.getString(com.pocketlawyer.`in`.R.string.pdf_subject_prefix) + subjectFor(context, typeId)
        canvas.drawText(subjectLine, marginLeft, y, boldPaint)
        y += lineHeight + paraGap

        // Salutation
        canvas.drawText(context.getString(com.pocketlawyer.`in`.R.string.pdf_salutation), marginLeft, y, bodyPaint)
        y += lineHeight + paraGap

        // Opening paragraph
        val nameText = complainantName.ifBlank { context.getString(com.pocketlawyer.`in`.R.string.pdf_undersigned) }
        val locationText = if (location.isNotBlank()) context.getString(com.pocketlawyer.`in`.R.string.pdf_at_location, location) else ""
        val dateText = if (incidentDate.isNotBlank()) context.getString(com.pocketlawyer.`in`.R.string.pdf_on_date, incidentDate) else ""
        
        drawParagraph(
            context.getString(com.pocketlawyer.`in`.R.string.pdf_opening_template, nameText, dateText, locationText),
            bodyPaint
        )

        // Details heading
        newPageIfNeeded(lineHeight * 2)
        canvas.drawText(context.getString(com.pocketlawyer.`in`.R.string.pdf_details_header), marginLeft, y, boldPaint)
        y += lineHeight + 4f

        // Description body
        val descriptionText = description.ifBlank {
            context.getString(com.pocketlawyer.`in`.R.string.pdf_no_description)
        }
        drawParagraph(descriptionText, bodyPaint)

        // Closing request paragraph
        drawParagraph(
            context.getString(com.pocketlawyer.`in`.R.string.pdf_closing),
            bodyPaint
        )

        y += 6f
        newPageIfNeeded(lineHeight * 6)
        canvas.drawText(context.getString(com.pocketlawyer.`in`.R.string.pdf_thanking_you), marginLeft, y, bodyPaint)
        y += lineHeight + 10f
        canvas.drawText(context.getString(com.pocketlawyer.`in`.R.string.pdf_yours_faithfully), marginLeft, y, bodyPaint)
        y += lineHeight * 2
        canvas.drawText("(${complainantName.ifBlank { context.getString(com.pocketlawyer.`in`.R.string.pdf_signature_hint) }})", marginLeft, y, bodyPaint)
        y += lineHeight
        canvas.drawText(context.getString(com.pocketlawyer.`in`.R.string.pdf_complainant_label), marginLeft, y, bodyPaint)

        // Footer disclaimer on the current page - wrapped so it never runs off the page edge
        val footerText = context.getString(com.pocketlawyer.`in`.R.string.pdf_footer_text)
        val footerLines = mutableListOf<String>()
        var footerLine = StringBuilder()
        for (word in footerText.split(" ")) {
            val candidate = if (footerLine.isEmpty()) word else "$footerLine $word"
            if (smallPaint.measureText(candidate) > contentWidth && footerLine.isNotEmpty()) {
                footerLines.add(footerLine.toString())
                footerLine = StringBuilder(word)
            } else {
                footerLine = StringBuilder(candidate)
            }
        }
        if (footerLine.isNotEmpty()) footerLines.add(footerLine.toString())
        var footerY = pageHeight - 30f - (footerLines.size - 1) * 12f
        for (line in footerLines) {
            canvas.drawText(line, marginLeft, footerY, smallPaint)
            footerY += 12f
        }

        document.finishPage(page)

        val dir = File(context.filesDir, "complaints").apply { mkdirs() }
        val file = File(dir, "complaint_${System.currentTimeMillis()}.pdf")
        FileOutputStream(file).use { document.writeTo(it) }
        document.close()
        return file
    }

    fun shareUriForFile(context: Context, file: File) =
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)

    fun downloadToPublicFolder(context: Context, file: File): File? {
        return try {
            val downloadDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
            if (!downloadDir.exists()) downloadDir.mkdirs()
            val destFile = File(downloadDir, "PocketLawyer_Complaint_${System.currentTimeMillis()}.pdf")
            file.copyTo(destFile, overwrite = true)
            destFile
        } catch (e: Exception) {
            null
        }
    }
}
